
import java.awt.geom.*;
import java.awt.*;
import java.util.*;

public class p2 extends ClobberBot
{
    ClobberBotAction currAction;
    WhatIKnow prevState;
    int shotclock;

    // Direction and action variables from ClobberBotAction.java
    final int NONE = 0;
    final int MOVE = 1;
    final int SHOOT = 2;
    final int UP = 4;
    final int DOWN = 8;
    final int LEFT = 16;
    final int RIGHT = 32;
        
    public p2(Clobber game)
    {
        super(game);
        mycolor = Color.orange;
    }
	/** ClobberBotAction is called to figure out what the bot is going to
	do.
	@param currState what the bot uses to base its decision one
	@return what the bot is going to do
	*/
    public ClobberBotAction takeTurn(WhatIKnow currState)
    {
        //System.out.println("Closest bot: " + getClosestBot(currState));
        
        if (currAction == null) prevState = currState;
               
        shotclock--;
        if(shotclock<=0)
        {
            shotclock=game.getShotFrequency()+1;
            currAction = new ClobberBotAction(SHOOT, getDirection(currState.me, getClosestBot(currState)));

        }
        
        else 
        {
           Point2D closestBullet = getClosestBullet(currState);
           Point2D closestBot = getClosestBot(currState);
           //System.out.println("bullet: " + getDistance(currState.me, closestBullet) + " bot: " + getDistance(currState.me, closestBot));
           if (getDistance(currState.me, closestBot) <= 150) {
           	
           		currAction = new ClobberBotAction(MOVE, 
           		opposite(getDirection(currState.me, closestBot)));
           	
           }
           if (getDistance(currState.me, closestBullet) <= 100) {
           	
           		currAction = new ClobberBotAction(MOVE, 
           		dodgeDirection(getDirection(getClosestBullet(prevState), closestBullet)));
           	
           }
           else currAction = new ClobberBotAction(MOVE, 
           		getDirection(currState.me, closestBot));
        }
        
        prevState = currState;
        return currAction;
    }

    public String toString()
    {
        return "p2";
    }
    
    private int getDirection(Point2D a, Point2D b) {
    	int dir = 0;
    	if (a.getY() > b.getY()) dir |=  4;  // down
    	if (a.getY() < b.getY()) dir |=  8;  // up
    	if (a.getX() > b.getX()) dir |=  16; // right
    	if (a.getX() < b.getX()) dir |=  32; // left
    	//System.out.println(dir);
    	return dir;
    }
    
    private double getDistance(Point2D a, Point2D b) {
    	 return Math.sqrt(Math.pow(a.getX() - b.getX(),2) + Math.pow(a.getY() - b.getY(),2));
    }
    
    private Point2D getClosestBot(WhatIKnow currState) {
    	Iterator<BotPoint2D> it = currState.bots.iterator();
		Point2D closest = new Point2D.Double(1000000, 1000000);
				
		while(it.hasNext())
        {
        	Point2D	test = it.next();
        	
        	if (getDistance(currState.me, test) < getDistance(currState.me,closest)) closest = test;
        } 
        return closest;
    }
    
    private Point2D getClosestBullet(WhatIKnow currState) {
    	Iterator<BulletPoint2D> it = currState.bullets.iterator();
		Point2D closest = new Point2D.Double(1000000, 1000000);
				
		while(it.hasNext())
        {
        	Point2D	test = it.next();
        	if (getDistance(currState.me, test) < getDistance(currState.me,closest)) closest = test;
        } 
        return closest;
    }
    
    private int opposite(int a) {
    	switch (a) {
    		case UP: 	return DOWN;
    		case DOWN:  return UP;
    		case LEFT:  return RIGHT;
    		case RIGHT: return LEFT;
    		
    		case UP | LEFT:    return DOWN | RIGHT;
    		case UP | RIGHT:   return DOWN | LEFT;
    		case DOWN | LEFT:  return UP | RIGHT;
    		case DOWN | RIGHT: return UP| LEFT;
    		default: return 0;
    	}
    	
    }
    
    private int dodgeDirection(int a) {
    	switch (a) {
    		case UP: return RIGHT;
    		case DOWN: return LEFT;
    		case LEFT: return UP;
    		case RIGHT: return DOWN;
			case UP | LEFT: return UP | RIGHT;
    		case UP | RIGHT: return DOWN | RIGHT;
    		case DOWN | LEFT: return UP | LEFT;
    		case DOWN | RIGHT: return DOWN | LEFT;
    		default: return 0;
    	}
    }
    
   
}


