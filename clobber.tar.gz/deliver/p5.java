
import java.awt.geom.*;
import java.awt.*;
import java.util.*;
import java.lang.*;

public class p5 extends ClobberBot
{

    ClobberBotAction currAction, shotAction;
    int shotclock;

    public p5(Clobber game)
    {
        super(game);
    }

    /** Here's an example of how to read the WhatIKnow data structure */
    private void showWhatIKnow(WhatIKnow currState)
    {
        System.out.println("My id is " + ((ImmutablePoint2D)(currState.me)).getID() + ", I'm at position (" + 
                           currState.me.getX() + ", " + currState.me.getY() + ")");
        System.out.print("Bullets: ");
        Iterator<BulletPoint2D> it = currState.bullets.iterator();
        while(it.hasNext())
        {
            System.out.print(it.next() + ", ");
        }
        System.out.println();

        System.out.print("Bots: ");
        Iterator<BotPoint2D> bit = currState.bots.iterator();
        while(bit.hasNext())
        {
            System.out.print(bit.next() + ", ");
        }
        System.out.println();
    }
		/**This method calculates distances based on the values of the x and y
locations of the bots and the bullets and reacts to the information.  
@return the action the bot should take
*/
    public ClobberBotAction takeTurn(WhatIKnow currState)
    {
				double[] distanceBults=new double[100];
				double[] distanceBots=new double[100];
				double[][] danger=new double[100][2];
				double[][] botLocs=new double[100][2];
				for (int i=0;i<100;i++)
				{
						distanceBults[i]=0;
				}
				for (int i=0;i<100;i++)
				{
						distanceBots[i]=0;
				}
				for (int i=0;i<100;i++)
				{
						danger[i][0]=0;
						danger[i][1]=0;
						botLocs[i][0]=0;
						botLocs[i][1]=0;
				}

				double mex=(double)(currState.me.getX());
				double mey=(double)(currState.me.getY());
				
				double r1=0;
				double r2=0;
				double r3=0;
				double r4=0;
				double r5=0;
				double r6=0;
				double r7=0;
				double r8=0;
				boolean shoot=true;
				int choice=100;
				double max=0;

				Iterator<BulletPoint2D> it =currState.bullets.iterator();
				int i=0;
				int count=0;
				while(it.hasNext())
				{
						i+=1;
						Point2D ku=it.next();
						distanceBults[i]=Math.sqrt((Math.pow(mex-ku.getX(),2))+(Math.pow(mey-ku.getY(),2)));
						if (distanceBults[i]<=100)
						{
							count+=1;
							danger[count][0]=ku.getX();
							danger[count][1]=ku.getY();
						}
				}
				Iterator<BotPoint2D> bit =currState.bots.iterator();

			  int k=0;	
				while(bit.hasNext())
				{
						k+=1;
						Point2D kp=bit.next();
						distanceBots[k]=Math.sqrt((Math.pow(mex-kp.getX(),2))+(Math.pow(mey-kp.getY(),2)));
						if (distanceBots[k]<=100)
						{
							count+=1;
							danger[count][0]=kp.getX();
							danger[count][1]=kp.getY();
							botLocs[count][0]=kp.getX();
							botLocs[count][1]=kp.getY();
						}
				}
				if (count>0)
				{
					for (int j=0;j<100;j++)
					{
						double[] dis=distance(mex,mey,danger[j][0],danger[j][1]);
						r1=(dis[0]+r1);
						r2=(dis[1]+r2);
						r3=(dis[2]+r3);
						r4=(dis[3]+r4);
						r5=(dis[4]+r5);
						r6=(dis[5]+r6);
						r7=(dis[6]+r7);
						r8=(dis[7]+r8);
					}
						r1=r1/count;
						r2=r2/count;
						r3=r3/count;
						r4=r4/count;
						r5=r5/count;
						r6=r6/count;
						r7=r7/count;
						r8=r8/count;
					
				max=Math.max(r1,Math.max(r2,Math.max(r3,Math.max(r4,Math.max(r5,Math.max(r6,Math.max(r7,r8)))))));
				
				if (mex==0 || mey==0)
				{
					if (mey==0)
					{
						if(mex==0)
						{
							max=Math.max(r3,Math.max(r4,r5));
						}
						else if (mex==500)
						{
							max=Math.max(r5,Math.max(r6,r7));
						}
						else if(mex<500 && mex!=0)
						{
							max=Math.max(r3,Math.max(r4,Math.max(r5,Math.max(r6,r7))));
						}
					}
					else if (mey!=0)
					{
						if (mex!=500)
						{
							max=Math.max(r1,Math.max(r2,Math.max(r3,Math.max(r4,r5))));
						}
						else if (mex==500)
						{
							max=Math.max(r1,Math.max(r2,r3));
						}
					}
				}
				if (mex==500||mey==500)
				{
					if (mey==500)
					{
						if (mex==500)
						{
							max=Math.max(r1,Math.max(r7,r8));
						}
						else if (mex!=500 && mex!=0)
						{
							max=Math.max(r1,Math.max(r2,Math.max(r3,Math.max(r7,r8))));
						}
					}
					else if (mey==500 && mex!=500 && mex!=0)
					{
						max=Math.max(r1,Math.max(r4,Math.max(r6,Math.max(r7,r8))));
					}
				}


				if (max==r1) choice=0;
				else if (max==r2)	choice=5;
				else if (max==r3) choice=3;
				else if (max==r4) choice=7;
				else if (max==r5) choice=1;
				else if (max==r6) choice=6;
				else if (max==r7) choice=2;
				else if (max==r8) choice=4;
				shoot=false;	
			}
				int probshot=rand.nextInt(9);
				int choiceshot=rand.nextInt(8);
        shotclock--;
        if(probshot>=4 && shoot==true && shotclock<=0)
        {
            shotclock=game.getShotFrequency()+1;
						for (int counter=0; counter<100;counter++)
						{
							if (mex-botLocs[counter][0]==0 && mey-botLocs[counter][1]>0)
								{choiceshot=0;}
							if (mex-botLocs[counter][0]==0 && mey-botLocs[counter][1]<0)
								{choiceshot=1;}
							if (mex-botLocs[counter][0]<0 && mey-botLocs[counter][1]==0)
								{choiceshot=3;}
							if (mex-botLocs[counter][0]>0 && mey-botLocs[counter][1]==0)
								{choiceshot=2;}
							if (mex-botLocs[counter][0]>0 && mey-botLocs[counter][1]>0 
											&& mex-botLocs[counter][0]!=0 && mey-botLocs[counter][1]!=0)
								{choiceshot=4;}
							if (mex-botLocs[counter][0]<0 && mey-botLocs[counter][1]>0)
								{choiceshot=5;}
							if (mex-botLocs[counter][0]<0 && mey-botLocs[counter][1]<0)
								{choiceshot=7;}
							if (mex-botLocs[counter][0]>0 && mey-botLocs[counter][1]<0)
								{choiceshot=6;}
						}
						switch(choiceshot)
            {
                case 0:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
                break;
                case 1:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
                break;
                case 2:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
                break;
                case 3:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
                break;
                case 4:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.LEFT);
                break;
                case 5:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                break;
                case 6:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                break;
                default:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                break;
            }
						max=0;
            return shotAction;
        }
       else if(currAction==null || rand.nextInt(20)>18)
        {
						if (probshot<5) choice=rand.nextInt(8);
            switch(choice)
            {
                case 0:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                break;
                case 1:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                break;
                case 2:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                break;
                case 3:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                break;
                case 4:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                break;
                case 5:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                break;
                case 6:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                break;
                default:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                break;
            }
        }
				max=0;
        return currAction;
    }
		/**This method takes the position of the p5 bot and calculates the
distances from the bot a bullet for each possible move. 
@return double[] distance */
		public double[] distance(double x, double y, double xb, double yb)
		{
			double d1=Math.sqrt(Math.pow(x-xb,2)+Math.pow(y-2-yb,2));
			double d2=Math.sqrt(Math.pow(x+2-xb,2)+Math.pow(y-2-yb,2));
			double d3=Math.sqrt(Math.pow(x+2-xb,2)+Math.pow(y-yb,2));
			double d4=Math.sqrt(Math.pow(x+2-xb,2)+Math.pow(y+2-yb,2));
			double d5=Math.sqrt(Math.pow(x,2)+Math.pow(y+2-yb,2));
			double d6=Math.sqrt(Math.pow(x-2-xb,2)+Math.pow(y+2-yb,2));
			double d7=Math.sqrt(Math.pow(x-2-xb,2)+Math.pow(y-yb,2));
			double d8=Math.sqrt(Math.pow(x-2-xb,2)+Math.pow(y-2-yb,2));
			double[] dis={d1,d2,d3,d4,d5,d6,d7,d8};

			return dis;
		}
	/** This method overrides the drawMe method in the main Clobberbot routine.*/
	 public void drawMe(Graphics page, Point2D me)
  	{
        int x,y;
        x=(int)me.getX() - Clobber.MAX_BOT_GIRTH/2 -1;
        y=(int)me.getY() - Clobber.MAX_BOT_GIRTH/2 -1;
        page.setColor(Color.red);
        page.fillOval(x+5,y,Clobber.MAX_BOT_GIRTH-9,Clobber.MAX_BOT_GIRTH-9);
        page.fillOval(x,y+5,Clobber.MAX_BOT_GIRTH-9,Clobber.MAX_BOT_GIRTH-9);
        page.fillOval(x-5,y,Clobber.MAX_BOT_GIRTH-9,Clobber.MAX_BOT_GIRTH-9);
        page.fillOval(x,y-5,Clobber.MAX_BOT_GIRTH-9,Clobber.MAX_BOT_GIRTH-9);
    }


    public String toString()
    {
        return "p5";
    }
}


