
import java.awt.geom.*;
import java.awt.*;
import java.util.*;

public class p7 extends ClobberBot
{

    ClobberBotAction currAction;
    ClobberBotAction shotAction;

    public p7( Clobber game )
    {
        super( game );
        mycolor = Color.red;

    }

    /* This is the takeTurn method.  It performs a series of tests to determine the course of action
     * the p7 ClobberBot will take.
     */

    public ClobberBotAction takeTurn( WhatIKnow currState )
    {
    	Date startTime, endTime;

	startTime = new Date( );

	int threat1 = 0, threat2 = 0, threat3 = 0, threat4 = 0;
	int threat5 = 0, threat6 = 0, threat7 = 0, threat8 = 0;
	int gameMinX, gameMaxX, gameMinY, gameMaxY;
	int shotClock = 0;
	int XYBuffer;
	int zone1Buffer = 70;
	int zone2Buffer = 55;
	int zone3Buffer = 35;
	int zone4Buffer = 25;
	int safeZone = 200;
	int j = 0;
	double x, y;
	double previousBulletX, previousBulletY;

	ArrayList<Integer> threatID = new ArrayList( );
	ArrayList<Double> threatX = new ArrayList( );
	ArrayList<Double> threatY = new ArrayList( );

	gameMinX = game.getMinX( );
	gameMaxX = game.getMaxX( );
	gameMinY = game.getMinY( );
	gameMaxY = game.getMaxX( );

	XYBuffer = (int)( 2 + ( Clobber.MAX_BOT_GIRTH + Clobber.BULLET_GIRTH ) / 2 );

	x = currState.me.getX( );
	y = currState.me.getY( );

	for (int i = 0; i < currState.bots.size( ); i++ ) {
		double botX = currState.bots.get( i ).getX( ), botY = currState.bots.get( i ).getY( );
		if( x <= ( botX + zone1Buffer ) && x >= ( botX - zone1Buffer ) && y <= ( botY + zone1Buffer ) && y >= ( botY - zone1Buffer ) ) {
			if( botX > x ) {
				if( botY > y )
					threat1++;
				else
					threat4++;
			}
			else {
				if( botY > y )
					threat2++;
				else
					threat3++;
			}
		}

		if( x <= ( botX + zone2Buffer ) && x >= ( botX - zone2Buffer ) && y <= ( botY + zone2Buffer ) && y >= ( botY - zone2Buffer ) ) {
			if( botX > x ) {
				if( botY > y )
					threat5++;
				else
					threat6++;
			}
			else {
				if( botY > y )
					threat7++;
				else
					threat8++;
			}
		}
	}

	if( threat5 > threat6 ) {
		if( threat5 > threat7 ) {
			if( threat5 > threat8 )
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.DOWN );
			else
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN );
		}
		else {
			if( threat7 > threat8 )
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP );
			else
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN );
		}
	}
	else {
		if( threat6 > threat7 ) {
			if( threat6 > threat8 )
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP );
			else
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN );
		}
		else {
			if( threat7 > threat8 )
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP );
			else
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN );
		}
	}

	if( threat1 > threat2 ) {
		if( threat1 > threat3 ) {
			if( threat1 > threat4 )
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN );
			else
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP );
		}
		else {
			if( threat3 > threat4 )
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP );
			else
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP );
		}
	}
	else {
		if( threat2 > threat3 ) {
			if( threat2 > threat4 )
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.DOWN );
			else
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP );
		}
		else {
			if( threat3 > threat4 )
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP );
			else
				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP);
		}
	}

	for( int i = 0; i < currState.bullets.size( ); i++ ) {

		double bulletX = currState.bullets.get( i ).getX( ), bulletY = currState.bullets.get( i ).getY( );

		if( x <= ( bulletX + zone1Buffer ) && x >= ( bulletX - zone1Buffer ) && y <= ( bulletY + zone1Buffer ) && y >= ( bulletY - zone1Buffer ) ) {
			threatID.add( new Integer( ( (ImmutablePoint2D)currState.bullets.get( i ) ).getID( ) ) );
			threatX.add( new Double( currState.bullets.get( i ).getX( ) ) );
			threatY.add( new Double( currState.bullets.get( i ).getY( ) ) );
		}
	}

	for( int i = 0; i < threatID.size( ); i++ ) {

		int bulletID = threatID.get( i );
		double bulletX = threatX.get( i );
		double bulletY = threatY.get( i );

		if( x <= ( bulletX + zone2Buffer ) && x >= ( bulletX - zone2Buffer ) && y <= ( bulletY + zone2Buffer ) && y >= ( bulletY - zone2Buffer ) ) {
			if( bulletX > x ) {
				if( bulletY > y ) {
					//Quadrant 4
					//System.out.println( "Quadrant 4" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.UP );
					}
				}
				else {
					//Quadrant 1
					//System.out.println( "Quadrant 1" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.DOWN );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.DOWN );
					}
				}
			}
			else {
				if( bulletY > y ) {
					//Quadrant 3
					//System.out.println( "Quadrant 3" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.UP );
					}
				}
				else {
					//Quadrant 2
					//System.out.println( "Quadrant 2" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.DOWN );
					}
				}
			}
		}
		if( x <= ( bulletX + zone3Buffer ) && x >= ( bulletX - zone3Buffer ) && y <= ( bulletY + zone3Buffer ) && y >= ( bulletY - zone3Buffer ) ) {
			if( bulletX > x ) {
				if( bulletY > y ) {
					//Quadrant 4
					//System.out.println( "Quadrant 4" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.UP );
					}
				}
				else {
					//Quadrant 1
					//System.out.println( "Quadrant 1" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.DOWN );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.DOWN );
					}
				}
			}
			else {
				if( bulletY > y ) {
					//Quadrant 3
					//System.out.println( "Quadrant 3" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.UP );
					}
				}
				else {
					//Quadrant 2
					//System.out.println( "Quadrant 2" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.DOWN );
					}
				}
			}
		}

		if( x <= ( bulletX + zone4Buffer ) && x >= ( bulletX - zone4Buffer ) && y <= ( bulletY + zone4Buffer ) && y >= ( bulletY - zone4Buffer ) ) {
			if( bulletX > x ) {
				if( bulletY > y ) {
					//Quadrant 4
					//System.out.println( "Quadrant 4" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.UP );
					}
				}
				else {
					//Quadrant 1
					//System.out.println( "Quadrant 1" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.DOWN );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.DOWN );
					}
				}
			}
			else {
				if( bulletY > y ) {
					//Quadrant 3
					//System.out.println( "Quadrant 3" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.UP );
					}
				}
				else {
					//Quadrant 2
					//System.out.println( "Quadrant 2" );
					currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP );
					//Zone Y
					if( bulletX < ( x + XYBuffer ) && bulletX > ( x - XYBuffer ) ) {
						//System.out.println( "Zone Y" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT );
					}
					//Zone X
					if( bulletY < ( y + XYBuffer ) && bulletY > ( x - XYBuffer ) ) {
						//System.out.println( "Zone X" );
						currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.DOWN );
					}
				}
			}
		}
		else {
			threatID.remove( i );
			threatX.remove( i );
			threatY.remove( i );
		}

		//System.out.println( x + ", " + y );
		//System.out.println( bulletX + ", " + bulletY );
	}

	if( threatID.size( ) == 0 && 0 == threat1 && threat1 == threat2 && threat2 == threat3 && threat3 == threat4 && threat4 == threat5 && threat5 == threat6 && threat6 == threat7 && threat7 == threat8 ) {

		//System.out.println( "No threats" );

		if( x < ( gameMaxX + gameMinX ) / 2 ) {

			if( y < ( gameMaxY + gameMinY ) / 2 ) {

				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.DOWN );
			}
			else {

				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP );
			}
		}
		else {

			if( y < ( gameMaxY + gameMinY ) / 2 ) {

				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN );
			}
			else {

				currAction = new ClobberBotAction( ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP );
			}
		}

		if( x < ( ( ( gameMaxX + gameMinX ) / 2 ) + safeZone ) && x > ( ( ( gameMaxX + gameMinX ) / 2 ) - safeZone ) && y < ( ( ( gameMaxY + gameMinY ) / 2 ) + safeZone ) && y > ( ( ( gameMaxY + gameMinY ) / 2 ) - safeZone ) ) {

			shotClock--;

			if( shotClock <= 0 ) {

				shotClock = game.getShotFrequency( ) + 1;

				switch( rand.nextInt( 8 ) ) {
					case 0:

						shotAction = new ClobberBotAction( ClobberBotAction.SHOOT, ClobberBotAction.UP );
						break;

					case 1:

						shotAction = new ClobberBotAction( ClobberBotAction.SHOOT, ClobberBotAction.DOWN );
						break;

					case 2:

						shotAction = new ClobberBotAction( ClobberBotAction.SHOOT, ClobberBotAction.LEFT );
						break;

					case 3:

						shotAction = new ClobberBotAction( ClobberBotAction.SHOOT, ClobberBotAction.RIGHT );
						break;

					case 4:

						shotAction = new ClobberBotAction( ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.LEFT );
						break;
					case 5:

						shotAction = new ClobberBotAction( ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT );
						break;

					case 6:

						shotAction = new ClobberBotAction( ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT );
						break;

					default:

						shotAction = new ClobberBotAction( ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT );
						break;
				}

			return shotAction;

			}
		}
	}

	endTime = new Date( );

	double elapsedTime = endTime.getTime( ) - startTime.getTime( );

	//System.out.println( elapsedTime );

	return currAction;
    }

    public String toString( )
    {
    	return "p7";
    }
}


