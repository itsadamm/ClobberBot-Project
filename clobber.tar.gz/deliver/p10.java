//p10.java
import java.awt.geom.*;
import java.awt.*;
import java.util.*;
import java.lang.*;

/** This creates the p10 Bot.
 * i use an icon image for my bot instead of drawing
 * to the screen
 *  */
public class p10 extends ClobberBot
{

    ClobberBotAction action;
    int minx;
    int miny;
    int maxx;
    int maxy;
    int swit=0;
    boolean firstturn = true;
    
    public p10(Clobber game)
    {
        super(game);
        mycolor = Color.orange;
	minx = game.getMinX();
	miny = game.getMinY();
	maxx = game.getMaxX();
	maxy = game.getMaxY();
    }

    /** Here's an example of how to read the WhatIKnow data structure */
    private void showWhatIKnow(WhatIKnow currState)
    {
        System.out.println("My id is " + ((ImmutablePoint2D)(currState.me)).getID() + ", I'm at position (" + 
                           currState.me.getX() + ", " + currState.me.getY() + ")");
        System.out.print("Bullets: ");
        Iterator<BulletPoint2D> it = currState.bullets.iterator();
        while(it.hasNext())
        {
            BulletPoint2D p = (BulletPoint2D)(it.next());
	    //System.out.print("XPLUS " + p.getXPlus());
	    //System.out.print("YPLUS " + p.getYPlus());
            System.out.print(p + ", ");
        }
        System.out.println();

        System.out.print("Bots: ");
        Iterator<BotPoint2D> bit = currState.bots.iterator();
        while(bit.hasNext())
        {
	    BotPoint2D b = (BotPoint2D)(bit.next());
	    //System.out.print("XPLUS " + b.getX());
	    //System.out.print("YPLUS " + b.getY());
            System.out.print(b + ", ");
        }
        System.out.println();
    }

    /**
     * 	Method that tells my bot what to do on my turn.
     *  @param currState is the current state of what i know.
     *  @return the ClobberBotAction I wish to do.
     */
    public ClobberBotAction takeTurn(WhatIKnow currState)
    {
    	//showWhatIKnow(currState); // @@@ Uncomment this line to see it print out all bullet and bot positions every turn
	//my coordinates
	double myx = currState.me.getX();
	double myy = currState.me.getY();
	//closest enemy bot infor
	BotPoint2D bot = findBot(currState);
	double botx = bot.getX();
	double boty = bot.getY();
	//double d = Point2D.distance(myx,myy,botx,boty);
	//closest bullet?
	BulletPoint2D bullet = findBullet(currState);
	//if closest bullet is close i'll want to move
	if(firstturn == false && bullet!= null)
	{	//bullet info
		double bulletx = bullet.getX();
		double bullety = bullet.getY();
		//if bullet is within 60
		if(Point2D.distance(myx,myy,bulletx,bullety) <= 60)
		{	//bullet traveling DOWN | RIGHT
			if((bullet.getYPlus() > 0) && (bullet.getXPlus() > 0) && (myy > bullety) && (myx > bulletx) && (Math.abs(Math.abs(myx-bulletx) - Math.abs(myy-bullety)) < 20))
			{	return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
			}
			//bullet traveling DOWN | LEFT
			if((bullet.getYPlus() > 0) && (bullet.getXPlus() < 0) && (myy > bullety) && (myx < bulletx) && (Math.abs(Math.abs(myx-bulletx) - Math.abs(myy-bullety)) < 20))
			{	return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
			}
			//bullet traveling UP | LEFT
			if((bullet.getYPlus() < 0) && (bullet.getXPlus() > 0) && (myy < bullety) && (myx > bulletx) && (Math.abs(Math.abs(myx-bulletx) - Math.abs(myy-bullety)) < 20))
			{	return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
			}
			//bullet traveling UP | RIGHT
			if((bullet.getYPlus() < 0) && (bullet.getXPlus() < 0) && (myy < bullety) && (myx < bulletx) && (Math.abs(Math.abs(myx-bulletx) - Math.abs(myy-bullety)) < 20))
			{	return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
			}
			//bullet traveling RIGHT
			if((bullet.getXPlus() > 0) && (bullet.getYPlus() == 0) && (myx > bulletx) && (Math.abs(myy-bullety) < 15))
			{	//if my center is higher then bullet center
				if(myy<bullety && (Math.abs(myy-miny) < 10 || Math.abs(myy-maxy) <10))  return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
				//if my center is lower then bullet center
				else  return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
			}
			//bullet traveling LEFT
			if((bullet.getXPlus() < 0) && (bullet.getYPlus() == 0) && (myx < bulletx) && (Math.abs(myy-bullety) < 15))
			{	if(myy<bullety && (Math.abs(myy-miny) < 10 || Math.abs(myy-maxy) <10))  return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
				else  return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
			}
			//bullet traveling UP
			if((bullet.getYPlus() < 0) && (bullet.getXPlus() == 0) && (myy < bullety) && (Math.abs(myx-bulletx) < 15))
			{	if(myx<bulletx && (Math.abs(myx-minx) < 10 || Math.abs(myx-maxx) <10))  return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
				else  return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
			}
			//bullet traveling DOWN
			if((bullet.getYPlus() > 0) && (bullet.getXPlus() == 0) && (myy > bullety) && (Math.abs(myx-bulletx) < 15))
			{	if(myx<bulletx && (Math.abs(myx-minx) < 10 || Math.abs(myx-maxx) <10))  return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
				else  return action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
			}
		}
	}
	//else i want to align with or shoot at the closest bot
	if(myx-botx <= 0 && myy-boty <=0)
	{	//to align horizontally
		if(myx<botx)
		{	if(myy<boty || myy==miny)
			{	action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
			}
			if(myy>boty || myy==maxy)
			{	action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
			}
			if(myy==boty || Math.abs(myy-boty) < 10)
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
			}
			if(myy<boty && (Math.abs(Math.abs(myx-botx) - Math.abs(myy-boty)) < 20))
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
			}
			if(myy>boty && (Math.abs(Math.abs(myx-botx) - Math.abs(myy-boty)) < 20))
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
			}
		}
		else if(myx>botx)
		{	if(myy<boty || myy==miny)
			{	action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
			}
			if(myy>boty || myy==maxy)
			{	action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
			}
			if(myy==boty || Math.abs(myy-boty) < 10)
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
			}
			if(myy<boty && (Math.abs(Math.abs(myx-botx) - Math.abs(myy-boty)) < 20))
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
			}
			if(myy>boty && (Math.abs(Math.abs(myx-botx) - Math.abs(myy-boty)) < 20))
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.LEFT);
			}
		}
		else if(myx==botx || Math.abs(myx-botx) < 100)
		{	if(myy<boty)
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
			}
			if(myy>boty)
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
			}
		}
	}
	else
	{	//to align vertically
		if(myy<boty)
		{	if(myx<botx || myx==maxx)
			{	action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
			}
			if(myx>botx || myx==minx)
			{	action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
			}
			if(myx==botx || Math.abs(myx-botx) < 10)
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
			}
			if(myx<botx && (Math.abs(Math.abs(myx-botx) - Math.abs(myy-boty)) < 20))
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
			}
			if(myx>botx && (Math.abs(Math.abs(myx-botx) - Math.abs(myy-boty)) < 20))
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
			}
		}
		else if(myy>boty)
		{	if(myx<botx || myx==maxx)
			{	action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
			}
			if(myx>botx || myx==minx)
			{	action = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
			}
			if(myx==botx || Math.abs(myx-botx) < 10)
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
			}
			if(myx<botx && (Math.abs(Math.abs(myx-botx) - Math.abs(myy-boty)) < 20))
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
			}
			if(myx>botx && (Math.abs(Math.abs(myx-botx) - Math.abs(myy-boty)) < 20))
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.LEFT);
			}
		}
		else if(myy==boty || Math.abs(myy-boty) < 100)
		{	if(myx<botx)
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
			}
			if(myx>botx)
			{	action = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
			}
		}
	}
	firstturn = false;
	return action;
}

	/**
	 *  This method finds the closest bot to me and returns it to takeTurn
	 *  @param currState is the current state of the game
	 *  @return is the closest bot to me
	 */
	private BotPoint2D findBot(WhatIKnow currState)
	{
		Iterator<BotPoint2D> botit = currState.bots.iterator();
		BotPoint2D finalbot = null;
		double botdist1 = 1000000.0;
		double botdist2 = 10000.0;
		while(botit.hasNext())
		{	BotPoint2D bot1 = (BotPoint2D)botit.next();
			botdist1 = Point2D.distance(currState.me.getX(),currState.me.getY(),bot1.getX(),bot1.getY());
			//System.out.println(botdist1 + "\n");
			if(Math.abs(currState.me.getX()-bot1.getX()) < 10 || Math.abs(currState.me.getX()-bot1.getX()) < 10)
			{	finalbot = bot1;
			}
			if(botdist1 < botdist2)
			{
				botdist2 = botdist1;
				finalbot = bot1;
			}
		}
		//System.out.println(finalbot);
		return finalbot;
	}

	/**
	 *  This method finds the closest bullet to me and returns it to takeTurn
	 *  @param currState is the current state of the game
	 *  @return is the closest bullet to me
	 */
	private BulletPoint2D findBullet(WhatIKnow currState)
	{
		Iterator<BulletPoint2D> bullit = currState.bullets.iterator();
		BulletPoint2D finalbullet = null;
		double bulldist1 = 1000000.0;
		double bulldist2 = 10000.0;
		while(bullit.hasNext())
		{	BulletPoint2D bull1 = (BulletPoint2D)bullit.next();
			bulldist1 = Point2D.distance(currState.me.getX(),currState.me.getY(),bull1.getX(),bull1.getY());
			if(bulldist1 < bulldist2)
			{
				bulldist2 = bulldist1;
				finalbullet = bull1;
			}
		}
		return finalbullet;
	}

    /** Draws the clobber bot to the screen.  The drawing should be 
     * centered at the point me.
     * My bot is an spaceship with a green alien in it*/
    public void drawMe(Graphics page, Point2D me) 
    {
        int x,y,m,n;
        x=(int)me.getX() - Clobber.MAX_BOT_GIRTH/2 -1;
        y=(int)me.getY() - Clobber.MAX_BOT_GIRTH/2 -1;
        m = (int)me.getX();
        n = (int)me.getY();

	//dome of the alien spaceship
	page.setColor(Color.white);
	page.drawOval(x+3,y,Clobber.MAX_BOT_GIRTH-6,(int)Clobber.MAX_BOT_GIRTH/2+1);
	
	//body of the alien spaceship
	page.setColor(mycolor);
	page.fillOval(x,n,Clobber.MAX_BOT_GIRTH,(int)Clobber.MAX_BOT_GIRTH/2+1);

	//alien
	page.setColor(Color.green);
	//head
	page.fillOval(x+5,y+3,Clobber.MAX_BOT_GIRTH-10,(int)Clobber.MAX_BOT_GIRTH/2-2);
	//antennae
	page.drawLine(m,n,m+8,n-8);
	page.drawLine(m,n,m-8,n-8);

	//decorations on the alien spaceship
	page.setColor(Color.blue);
	page.drawLine(m+3,n+2,m+3,n+6);
	page.drawLine(m-3,n+2,m-3,n+6);
    }

    public String toString()
    {
        return "p10";
    }
}


