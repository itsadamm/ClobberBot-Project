import java.awt.*;
import java.util.*;
import java.awt.geom.*;
public class p4 extends ClobberBot
{
    ArrayList<Double> bulletsX, bulletsY, botsX, botsY;//holds X and Y values of bullets and bots
    ClobberBotAction currAction;
    int shotclock;
    
    public p4(Clobber game)
    {
        super(game);
        bulletsX = new ArrayList<Double>();
        bulletsY = new ArrayList<Double>();
        botsX = new ArrayList<Double>();
        botsY = new ArrayList<Double>();
        shotclock = game.getShotFrequency();
    }
    
    /**
     * @return ClobberBotAction
     * @param WhatIKnow
     */
    public ClobberBotAction takeTurn(WhatIKnow whatiknow)
    {
        shotclock--;
        double myX = whatiknow.me.getX();
        double myY = whatiknow.me.getY();
        
        for(int j = 0; j< bulletsX.size(); j++)//removing all bullets from bullet list
        {
                bulletsX.remove(j);
                bulletsY.remove(j);
        }
        for(int j = 0; j< botsY.size(); j++)//removing all bots from bot list
        {
                botsY.remove(j);
                botsX.remove(j);
        }
        
        for(int i = 0; i < whatiknow.bots.size(); i++)
        {
                botsX.add((Double)((Point2D)whatiknow.bots.get(i)).getX());//adding x-coordinate of bots to botsX
                botsY.add((Double)((Point2D)whatiknow.bots.get(i)).getY());//adding y-coordinate of bots to botsY
        }
        
        if(whatiknow.bullets.size() != 0)//make sure there ARE bullets
        {
                for(int i = 0; i < whatiknow.bullets.size(); i++)
                {
                    bulletsX.add(whatiknow.bullets.get(i).getX());//adding x-coord of all bullets to bulletsX
                    bulletsY.add(whatiknow.bullets.get(i).getY());//adding y-coord of all bullets to bulletsY
                }
        }
        
        if((bulletDanger(myX, myY, bulletsX, bulletsY, whatiknow.bullets.size()) != false))
        {
            boolean safeLeft = false, safeUp = false, safeRight = false, safeDown = false, safeUpLeft = false, safeUpRight = false, safeDownLeft = false, safeDownRight = false;

            safeLeft = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "left");    
            safeRight = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "right");  
            safeUp = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "up");
            safeDown = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "down");
            safeUpLeft = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "upLeft");
            safeUpRight = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "upRight");
            safeDownLeft = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "downLeft");
            safeDownRight = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "downRight");
            int closestBullet = getClosestBullet(myX, myY, bulletsX, bulletsY, whatiknow.bullets.size());
                switch(closestBullet)
                {
                    case 8:
                        if(safeLeft && !atLeft(myX, myY))
                            if(safeUpLeft && !atTop(myX, myY)) 
                                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                            else if(safeDownLeft && !atLeft(myX, myY) && !atBottom(myX, myY))
                                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
                        else 
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.DOWN);
                        break;
                    case 7:
                        if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeUpRight && !atRight(myX, myY) && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(safeDownRight && !atRight(myX, myY) && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.DOWN);
                        break;
                    case 6:
                        if(safeRight && !atRight(myX, myY)) 
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(safeUpLeft && !atLeft(myX, myY) && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP);
                        else if(safeUpRight && !atRight(myX, myY) && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.UP);
                        break;
                    case 5:
                        if(safeUpRight && !atTop(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(safeUpLeft && !atTop(myX, myY) && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                        else if(safeRight && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.UP);
                        break;
                    case 4:
                        if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeUpLeft && !atTop(myX, myY) && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                        else if(safeUpRight && !atTop(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.DOWN);
                        break;
                    case 3:
                        if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeRight && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(safeDownLeft && !atLeft(myX, myY) && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else if(safeUpRight && !atTop(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.DOWN);
                        break;
                    case 2:
                        if(safeRight && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(safeUpLeft && !atTop(myX, myY) && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                        else if(safeUpRight && !atTop(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(safeDownLeft && !atBottom(myX, myY) && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else if(safeDownRight && !atBottom(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.UP);
                        break;
                    case 1:
                        if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeRight && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(safeDownRight && !atBottom(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else if(safeDownLeft && !atLeft(myX, myY) && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.UP);
                        break;
                }
                return currAction;
        }
        
        else if((botDanger(myX, myY, botsX, botsY, whatiknow.bots.size()) == true))
        {
            int closestBot = getClosestBot(myX, myY, botsX, botsY, whatiknow.bots.size());
            boolean safeLeft = false, safeUp = false, safeRight = false, safeDown = false, safeUpLeft = false, safeUpRight = false, safeDownLeft = false, safeDownRight = false;
            //quick + dirty way of checking to see if locations are all right to move to
            safeLeft = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "left");    
            safeRight = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "right");  
            safeUp = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "up");
            safeDown = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "down");
            safeUpLeft = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "upLeft");
            safeUpRight = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "upRight");
            safeDownLeft = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "downLeft");
            safeDownRight = safeTest(myX, myY, botsX, botsY, bulletsX, bulletsY, whatiknow.bots.size(), whatiknow.bullets.size(), "downRight");
                switch(closestBot)
                {
                    case 8:
                        if(safeLeft && !atLeft(myX, myY))
                            if(safeUpLeft && !atTop(myX, myY)) 
                                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                            else if(safeDownLeft && !atLeft(myX, myY) && !atBottom(myX, myY))
                                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
                        else 
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.DOWN);
                        break;
                    case 7:
                        if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeUpRight && !atRight(myX, myY) && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(safeDownRight && !atRight(myX, myY) && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.DOWN);
                        break;
                    case 6:
                        if(safeRight && !atRight(myX, myY)) 
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(safeUpLeft && !atLeft(myX, myY) && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP);
                        else if(safeUpRight && !atRight(myX, myY) && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.UP);
                        break;
                    case 5:
                        if(safeUpRight && !atTop(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(safeUpLeft && !atTop(myX, myY) && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                        else if(safeRight && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.UP);
                        break;
                    case 4:
                        if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeUpLeft && !atTop(myX, myY) && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                        else if(safeUpRight && !atTop(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.DOWN);
                        break;
                    case 3:
                        if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeRight && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(safeDownLeft && !atLeft(myX, myY) && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else if(safeUpRight && !atTop(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.DOWN);
                        break;
                    case 2:
                        if(safeRight && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(safeUpLeft && !atTop(myX, myY) && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                        else if(safeUpRight && !atTop(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else if(safeDownLeft && !atBottom(myX, myY) && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else if(safeDownRight && !atBottom(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.UP);
                        break;
                    case 1:
                        if(safeDown && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                        else if(safeUp && !atTop(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                        else if(safeRight && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                        else if(safeLeft && !atLeft(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                        else if(safeDownRight && !atBottom(myX, myY) && !atRight(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        else if(safeDownLeft && !atLeft(myX, myY) && !atBottom(myX, myY))
                            currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                        else if(shotclock <= 0)
                            currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        else
                            currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.UP);
                        break;
                }
                return currAction;
        }
        
        else if(shotclock <= 0 && (atTop(myX, myY) == false) && (atBottom(myX, myY) == false) && (atRight(myX, myY) == false) && (atLeft(myX, myY) == false))
        {
                shotclock=game.getShotFrequency()+1;
                int closestBot = getClosestBot(myX, myY, botsX, botsY, whatiknow.bots.size());
                switch(closestBot)
                {
                    case 8:
                        currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
                        break;
                    case 7:
                        currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                        break;
                    case 6:
                        currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
                        break;
                    case 5:
                        currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT | ClobberBotAction.DOWN);
                        break;
                    case 4:
                        currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
                        break;
                    case 3:
                        currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.LEFT);
                        break;
                    case 2:
                        currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
                        break;
                    case 1:
                        currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                        break;
                }
                return currAction;
            }
            else
            {
                if(atLeft(myX, myY) == true)
                    if(atTop(myX, myY) == true)
                        currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.DOWN);
                    else if(atBottom(myX, myY) == true)
                        currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP);
                    else
                        currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                else if(atRight(myX, myY) == true)
                    if(atTop(myX, myY) == true)
                        currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN);
                    else if(atBottom(myX, myY) == true)
                        currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP);
                    else
                        currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                else                               
                    currAction = createAction(ClobberBotAction.NONE, ClobberBotAction.LEFT);//don't do anything
                return currAction;
             }
    }
    /**
     * @return ClobberBotAction
     * @param int j, int i
     * Returns the created ClobberBotAction.
     */
    public static ClobberBotAction createAction(int j, int i)
    {
        ClobberBotAction action = new ClobberBotAction((byte)j, i);
        return action;
    }
    
    /**
     * tests to see if the surrounding areas are safe (e.g., free from bots, bullets, and edges.)
     * @return boolean
     */
    public boolean safeTest(double myX, double myY, ArrayList<Double> botsX, ArrayList<Double> botsY, ArrayList<Double> bulletsX, ArrayList<Double> bulletsY, int numBots, int numBullets, String area)
    {
        if(area.equals("up"))
        {
            for(int i = 0; i< numBots; i++)
            {
                if(botsY.get(i) < myY)//bot is above me somewhere
                    if((botsX.get(i) < (myX+30)) && (botsX.get(i) > (myX-30)))//will it even hit me if I DO move up?
                        return false;
            }
            for(int j = 0; j< numBullets; j++)
            {
                if(bulletsY.get(j) < myY)//bullet is above me somewhere
                    if((bulletsX.get(j) < (myX+20)) && (bulletsX.get(j) > (myX-20)))//will it even hit me if I DO move up?
                        return false;
            }
            return true; //up is safe to move to!
        }
        
        if(area.equals("down"))
        {
            for(int i = 0; i< numBots; i++)
            {
                if(botsY.get(i) > myY)//bot is beneath me somewhere
                    if((botsX.get(i) < (myX+30)) && (botsX.get(i) > (myX-30)))//will it even hit me if I DO move down?
                        return false;
            }
            for(int j = 0; j< numBullets; j++)
            {
                if(bulletsY.get(j) > myY)//bullet is beneath me somewhere
                    if((bulletsX.get(j) < (myX+20)) && (bulletsX.get(j) > (myX-20)))//will it even hit me if I DO move down?
                        return false;
            }
            return true; //down is safe to move to!
        }
        
        if(area.equals("right"))
        {
            for(int i = 0; i< numBots; i++)
            {
                if(botsX.get(i) > myX)//bot is on my right
                    if((botsY.get(i) < (myY-30)) && (botsY.get(i) > (myY+30)))//will bot even hit me if i DO move right?
                        return false;
            }
            for(int j = 0; j< numBullets; j++)
            {
                if(bulletsX.get(j) > myX)//bullet is on my right
                    if((bulletsY.get(j) < (myY-20)) && (bulletsY.get(j) > (myY+20)))//will bullet even hit me if i DO move right?
                        return false;
            }
            return true; 
        }
        
        if(area.equals("left"))
        {
            for(int i = 0; i< numBots; i++)
            {
                if(botsX.get(i) < myX)//bot is on my left
                    if((botsY.get(i) < (myY-30)) && (botsY.get(i) > (myY+30)))//will bot even hit me if i DO move left?
                        return false;//area not safe
            }
            for(int j = 0; j< numBullets; j++)
            {
                if(bulletsX.get(j) < myX)//bullet is on my left
                    if((bulletsY.get(j) < (myY-20)) && (bulletsY.get(j) > (myY+20)))//will bullet even hit me if i DO move left?
                        return false;//area not safe
            }
            return true; //area safe
        }
        
        if(area.equals("upRight"))
        {
            for(int i = 0; i< numBots; i++)
            {
                if((botsX.get(i) > myX) && (botsY.get(i) < myY))
                    if(Math.sqrt(Math.pow(botsX.get(i) - myX, 2) + Math.pow(botsY.get(i) - myY, 2)) < 30)
                        return false;
            }
            for(int j = 0; j< numBullets; j++)
            {
                if((bulletsX.get(j) > myX) && (bulletsY.get(j) < myY))
                    if(Math.sqrt(Math.pow(bulletsX.get(j) - myX, 2) + Math.pow(bulletsY.get(j) - myY, 2)) < 20)
                        return false;
            }
            return true;     
        }
        
        if(area.equals("upLeft"))
        {
            for(int i = 0; i< numBots; i++)
            {
                if((botsX.get(i) < myX) && (botsY.get(i) < myY))
                    if(Math.sqrt(Math.pow(botsX.get(i) - myX, 2) + Math.pow(botsY.get(i) - myY, 2)) < 30)
                        return false;
            }
            for(int j = 0; j< numBullets; j++)
            {
                if((bulletsX.get(j) < myX) && (bulletsY.get(j) < myY))
                    if(Math.sqrt(Math.pow(bulletsX.get(j) - myX, 2) + Math.pow(bulletsY.get(j) - myY, 2)) < 20)
                        return false;
            }
            return true;     
        }
        
        if(area.equals("downRight"))
        {
            for(int i = 0; i< numBots; i++)
            {
                if((botsX.get(i) > myX) && (botsY.get(i) > myY))
                    if(Math.sqrt(Math.pow(botsX.get(i) - myX, 2) + Math.pow(botsY.get(i) - myY, 2)) < 30)
                        return false;
            }
            for(int j = 0; j< numBullets; j++)
            {
                if((bulletsX.get(j) > myX) && (bulletsY.get(j) > myY))
                    if(Math.sqrt(Math.pow(bulletsX.get(j) - myX, 2) + Math.pow(bulletsY.get(j) - myY, 2)) < 20)
                        return false;
            }
            return true;     
        }
        
        if(area.equals("downLeft"))
        {
            for(int i = 0; i< numBots; i++)
            {
                if((botsX.get(i) < myX) && (botsY.get(i) > myY))
                    if(Math.sqrt(Math.pow(botsX.get(i) - myX, 2) + Math.pow(botsY.get(i) - myY, 2)) < 30)
                        return false;
            }
            for(int j = 0; j< numBullets; j++)
            {
                if((bulletsX.get(j) < myX) && (bulletsY.get(j) > myY))
                    if(Math.sqrt(Math.pow(bulletsX.get(j) - myX, 2) + Math.pow(bulletsY.get(j) - myY, 2)) < 20)
                        return false;
            }
            return true;     
        }
        return false;
    }
    /**
     * Tests to see if your bot is at the bottom of the screen.
     * @return boolean
     */
    public boolean atBottom(double myX, double myY)
    {
        if((game.getMaxY() - 20) < myY)
        {
            return true;
        }
        return false;
    }
    /**
     * Tests to see if your bot is at the top of the screen.
     * @return boolean
     */
    public boolean atTop(double myX, double myY)
    {
        if((game.getMinY() + 20) > myY)
        {
            return true;
        }
        return false;
    }
    /**
     * Tests to see if your bot is at the right of the screen.
     * @return boolean
     */
    public boolean atRight(double myX, double myY)
    {
        if((game.getMaxX() - 20) < myX)
        {
            return true;
        }
        return false;
    }
    /**
     * Tests to see if your bot is at the left of the screen
     * @return boolean
     */
    public boolean atLeft(double myX, double myY)
    {
        if((game.getMinX() + 20) > myX)
        {
            return true;
        }
        return false;
    }
    /**
     * Tests to see if your bot is in danger by finding the closest bot and seeing if the distance between you both is less than 35
     * if it is, return true.
     * @return boolean
     */
    public boolean botDanger(double myX, double myY, ArrayList<Double> botsX, ArrayList<Double> botsY, int numBots)//is there a bot nearby to cause danger?
    {
        double distance = 1000D;
         for(int i = 0; i < numBots; i++)
        {           
            if(Math.sqrt(Math.pow(myX-botsX.get(i), 2) + Math.pow(myY-botsY.get(i), 2)) < distance)
            {
                distance = Math.sqrt(Math.pow(botsX.get(i)-myX, 2) + Math.pow(botsY.get(i)-myY, 2));
            }
        }
        if(distance > 35) //not in danger
            return false;
        return true;
    }
    /**
     * Tests to see if your bot is in danger by finding the closest bullet and seeing if the distance between you both is less than 70
     * If it is, return true.
     * @return boolean
     */
    public boolean bulletDanger(double myX, double myY, ArrayList<Double> bulletsX, ArrayList<Double> bulletsY, int numBullets)//is there a bullet nearby to cause danger?
    {
        double distance = 1000D;
         for(int i = 0; i < numBullets; i++)
        {           
            if(Math.sqrt(Math.pow(myX-bulletsX.get(i), 2) + Math.pow(myY-bulletsY.get(i), 2)) < distance)
            {
                distance = Math.sqrt(Math.pow(bulletsX.get(i)-myX, 2) + Math.pow(bulletsY.get(i)-myY, 2));
            }
        }
        if(distance > 70)//not in danger
            return false;
        return true;
    }
    /**
     * returns a number which represents where the nearest bot is located.
     * @return int
     */
    public int getClosestBot(double myX, double myY, ArrayList<Double> botsX, ArrayList<Double> botsY, int numBots) // returns the orientation of you to the closest bot
    {
        double closestX = botsX.get(0), closestY = botsY.get(0), distance = 1000D;
        for(int i = 0; i < numBots; i++)
        {           
            if(Math.sqrt(Math.pow(botsX.get(i)-myX, 2) + Math.pow(botsY.get(i)-myY, 2)) < distance)
            {
                distance = Math.sqrt(Math.pow(botsX.get(i)-myX, 2) + Math.pow(botsY.get(i)-myY, 2));
                closestX = botsX.get(i);
                closestY = botsY.get(i);
            }
        }
        
        double angle = Math.toDegrees(Math.atan((double)(myY - closestY)/(double)(myX - closestX))); //getting the angle from your bot to the other bot
        if((angle <= -30) && (angle > -50))
            return 1;
        
        else if((angle <= -50) && (angle > -120))
            return 2;
        
        else if((angle <= -120) && (angle > -150))
            return 3;
        
        else if(((angle >= 150) && (angle <= 180)) || ((angle <= -150) && (angle >= -180)))
            return 4;
            
        else if((angle >= 120) && (angle < 150))
            return 5;
        
        else if((angle >= 50) && (angle < 120))
            return 6;
        
        else if((angle >= 30) && (angle < 50))
            return 7;

        else
            return 8;
        
    }
    /**
     * returns a number which represents where the nearest bullet is located.
     * @return int
     */
    public int getClosestBullet(double myX, double myY, ArrayList<Double> bulletsX, ArrayList<Double> bulletsY, int numBullets) // returns an action telling you to move away from the closest bullet
    {
        double closestX = botsX.get(0), closestY = botsY.get(0), distance = 1000D;
        for(int i = 0; i < numBullets; i++)
        {           
            if(Math.sqrt(Math.pow(bulletsX.get(i)-myX, 2) + Math.pow(bulletsY.get(i)-myY, 2)) < distance)
            {
                distance = Math.sqrt(Math.pow(bulletsX.get(i)-myX, 2) + Math.pow(bulletsY.get(i)-myY, 2));
                closestX = bulletsX.get(i);
                closestY = bulletsY.get(i);
            }
        }
        
        double angle = Math.toDegrees(Math.atan((double)(myY - closestY)/(double)(myX - closestX))); //getting the angle from your bot to the other bot in degrees

        if((angle <= -30) && (angle > -50))
            return 1;
        
        else if((angle <= -50) && (angle > -120))
            return 2;
        
        else if((angle <= -120) && (angle > -150))
            return 3;
        
        else if(((angle >= 150) && (angle <= 180)) || ((angle <= -150) && (angle >= -180)))
            return 4;
            
        else if((angle >= 120) && (angle < 150))
            return 5;
        
        else if((angle >= 50) && (angle < 120))
            return 6;
        
        else if((angle >= 30) && (angle < 50))
            return 7;

        else
            return 8;
        
    }
    /**
     * Draws your bot.
     */
    public void drawMe(Graphics g, Point2D point)
    {
        g.setColor(Color.magenta.darker());
        g.fill3DRect((int)point.getX()-8, (int)point.getY()-8, 14, 14, true);
        g.setColor(Color.pink);
        g.drawOval((int)point.getX(), (int)point.getY()-4, 4, 4);
        g.drawOval((int)point.getX()-4, (int)point.getY(), 4, 4);
        g.drawOval((int)point.getX()-4, (int)point.getY()-4, 4, 4);
        if((shotclock > 15) && (shotclock < 21))
        {
            g.setColor(Color.yellow);
            g.fillOval((int)point.getX(), (int)point.getY()-4, 4, 4);
            g.fillOval((int)point.getX()-4, (int)point.getY(), 4, 4);
            g.fillOval((int)point.getX()-4, (int)point.getY()-4, 4, 4);            
        }
        else
        {
            g.setColor(Color.magenta);
            g.fillOval((int)point.getX(), (int)point.getY()-4, 4, 4);
            g.fillOval((int)point.getX()-4, (int)point.getY(), 4, 4);
            g.fillOval((int)point.getX()-4, (int)point.getY()-4, 4, 4);
        }
    }
    /**
     * Returns the string representation of this bot.
     */
    public String toString()
    {
        return "p4";
    }
}
