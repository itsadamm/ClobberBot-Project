
import java.util.*;
import java.awt.*;
import java.awt.geom.*;


/*  
* Clobber Bot Agent
* Bot Chaney
* @author (Chad Haney)
* @version (12-06-05)
*/

public class p9 extends ClobberBot
{

    ClobberBotAction currAction, shotAction;
    int shotclock;
    int action;
    double x;
    double y;
    int i;
    int a;
    int d;
    int e;
    int b=0;
    int z=0; 
    private ArrayList bullets;
    private String bot;
    private String bullet;
    private ArrayList bots;

    public p9(Clobber game)
    {
        super(game);
        ArrayList bullets = new ArrayList();
        ArrayList bots = new ArrayList();
        mycolor = Color.white;
    }

    public void drawMe(Graphics page, Point2D me)
    {
    	if (z==0 || z==6)
	{
	z=1;
	}
	
	int d,e;
	d = (int)me.getX() - Clobber.MAX_BOT_GIRTH/2 - 1;
	e = (int)me.getY() - Clobber.MAX_BOT_GIRTH/2 - 1;
	page.setColor(Color.white);
	page.drawOval(d,e, Clobber.MAX_BOT_GIRTH, Clobber.MAX_BOT_GIRTH);

	page.setColor(Color.white);
	page.fillOval(d + (Clobber.MAX_BOT_GIRTH/3),e +
	(Clobber.MAX_BOT_GIRTH/3),
	Clobber.MAX_BOT_GIRTH/2,Clobber.MAX_BOT_GIRTH/2);
	page.setColor(Color.red);
	
	page.fillRect(d + (Clobber.MAX_BOT_GIRTH/2), e +
	(Clobber.MAX_BOT_GIRTH/2), Clobber.MAX_BOT_GIRTH/4,
	Clobber.MAX_BOT_GIRTH/z-6);
	
	page.fillRect(d + (Clobber.MAX_BOT_GIRTH/2), e +
	(Clobber.MAX_BOT_GIRTH/2), Clobber.MAX_BOT_GIRTH/z-6, Clobber.MAX_BOT_GIRTH/4);
	
	page.fillRect( (d - (Clobber.MAX_BOT_GIRTH/2/(z-6))), e + (Clobber.MAX_BOT_GIRTH/2), Clobber.MAX_BOT_GIRTH/z, Clobber.MAX_BOT_GIRTH/4);
    	
	page.fillRect(d + (Clobber.MAX_BOT_GIRTH/2), e -
	(Clobber.MAX_BOT_GIRTH/2/(z-6)), Clobber.MAX_BOT_GIRTH/4,
	Clobber.MAX_BOT_GIRTH/z);
	
	page.drawArc(d - (Clobber.MAX_BOT_GIRTH/3), e -
	(Clobber.MAX_BOT_GIRTH/3), Clobber.MAX_BOT_GIRTH+10, Clobber.MAX_BOT_GIRTH +10, (z*72),  70);
        page.setColor(Color.blue);
	page.drawArc(d - (Clobber.MAX_BOT_GIRTH/3), e
	-(Clobber.MAX_BOT_GIRTH/3), Clobber.MAX_BOT_GIRTH+10,
	Clobber.MAX_BOT_GIRTH +10, (z*72)+180, 70);
    if(b==0 || b%5==0)
    {z++;}
    b++;
    }
    
    /** Here's an example of how to read teh WhatIKnow data structure */
    private void showWhatIKnow(WhatIKnow currState)
    {
        System.out.println("My id is " + ((ImmutablePoint2D)(currState.me)).getID() + ", I'm at position (" + 
                           currState.me.getX() + ", " + currState.me.getY() + ")");
        System.out.print("Bullets: ");
        Iterator<BulletPoint2D> it = currState.bullets.iterator();
        while(it.hasNext())
        {
            System.out.print(it.next() + ", ");
        }
        System.out.println();

        System.out.print("Bots: ");
        Iterator<BotPoint2D> bit = currState.bots.iterator();
        while(bit.hasNext())
        {
            System.out.print(bit.next() + ", ");
        }
        System.out.println();
    }

    public void storeBullets()
    {

       ArrayList bullets = new ArrayList();
       
     
     // remove robots that are not within 50 marks near me
       
      for (i=0; i < bullets.size(); i++)
        {
           
           String bulletTemp = "" + bullets.get(i);
            Scanner sc = new Scanner(bulletTemp);
	    sc.next();
            Double xTemp = sc.nextDouble(); 
            Double yTemp = sc.nextDouble();
        
	if(((x - xTemp) < 50 && (x - xTemp) > 0) || ((xTemp - x) < 50 && (xTemp - x) > 0))
                {}
                else {
                    if( (y - yTemp) < 50 && (y - yTemp) > 0 || (yTemp - y) < 50 && (yTemp - y) > 0)
                        {}
                         else {
                               bullets.remove(i);
                              }
                     }
       } 
       
       // find nearest bullet and dodge
       
       for (i=0; i < bullets.size(); i++)
       {
            String bulletTemp = "" + bullets.get(i);
            Scanner sc = new Scanner(bulletTemp);
	    sc.next();
            Double xTemp = sc.nextDouble();
            Double yTemp = sc.nextDouble();
            
            if ((x - xTemp) < 20 && (x - xTemp) > 0 || ((xTemp - x) < 20 && (xTemp - x) > 0) && (y - yTemp) > 0)
            {
                action = 7;
            }
            
            if ((x - xTemp) < 20 && (x - xTemp) > 0 || ((xTemp - x) < 20 && (xTemp - x) > 0) && (y - yTemp) < 0)
            {
                action = 4;
            }         
            if ((y - yTemp) < 20 && (y - yTemp) > 0 || ((yTemp - y) < 20 && (yTemp - y) > 0) && (x - xTemp) > 0)
            {
                action = 5;
            }
            if ((y - yTemp) < 20 && (y - yTemp) > 0 || ((yTemp - y) < 20 && (yTemp - y) > 0) && (x - xTemp) < 0)
            {
                action = 6;
            }
            if (action == 9)
            {
                        if((x > xTemp) && (y > yTemp))
                        {
                            action = 3;
                        }
                        if ((x < xTemp) && (y < yTemp))
                        {
                            action = 2;
                        }
                        if ((x > xTemp) && (y < yTemp))
                        {
                            action = 0;
                        }
                        if ((x < xTemp) && (y > yTemp))
                        {
                            action = 1;
                        }
                      
 	    }
      }
   }
     
    public void storeBots()
    {
       ArrayList bots = new ArrayList();
       
     
     // remove robots that are not within 200 marks near me
       
      for (i=0; i < bots.size(); i++)
        {
           
           String botTemp = "" + bots.get(i);
            Scanner sc = new Scanner(botTemp);
	    sc.next();
            Double xTemp = sc.nextDouble(); 
            Double yTemp = sc.nextDouble();
            if(((x - xTemp) < 450 && (x - xTemp) > 0) || ((xTemp - x) < 450 && (xTemp - x) > 0))
                {}
                else {
                    if( (y - yTemp) < 450 && (y - yTemp) > 0 || (yTemp - y) <
		    450 && (yTemp - y) > 0)
                        {}
                         else {
                               bots.remove(i);
                              }
                     }
       } 
       
       // find best aim for bot and return as action
       
       for (i=0; i < bots.size(); i++)
       {
            String botTemp = "" + bots.get(i);
            Scanner sc = new Scanner(botTemp);
	    sc.next();
            Double xTemp = sc.nextDouble();
            Double yTemp = sc.nextDouble();
            
            if ((x - xTemp) < 75 && (x - xTemp) > 0 || ((xTemp - x) < 75 && (xTemp - x) > 0) && (y - yTemp) > 0)
            {
                action = 0;
            }
            
            if ((x - xTemp) < 75 && (x - xTemp) > 0 || ((xTemp - x) < 75 && (xTemp - x) > 0) && (y - yTemp) < 0)
            {
                action = 1;
            }         
            if ((y - yTemp) < 75 && (y - yTemp) > 0 || ((yTemp - y) < 75 && (yTemp - y) > 0) && (x - xTemp) > 0)
            {
                action = 2;
            }
            if ((y - yTemp) < 75 && (y - yTemp) > 0 || ((yTemp - y) < 75 && (yTemp - y) > 0) && (x - xTemp) < 0)
            {
                action = 3;
            }
            if (action == 9)
            {
                        if((x > xTemp) && (y > yTemp))
                        {
                            action = 4;
                        }
                        if ((x < xTemp) && (y < yTemp))
                        {
                            action = 7;
                        }
                        if ((x > xTemp) && (y < yTemp))
                        {
                            action = 6;
                        }
                        if ((x < xTemp) && (y > yTemp))
                        {
                            action = 5;
                        }
                        
            }
       }
    }
    
  
    
public ClobberBotAction takeTurn(WhatIKnow currState)
    {
        
        //showWhatIKnow(currState); // @@@ Uncomment this line to see it print out all bullet and bot positions every turn
        shotclock--; 
       
        
        bullets = new ArrayList();
      
        Iterator<BulletPoint2D> it = currState.bullets.iterator();
            
	    while (it.hasNext())
            {
            bullets.add(it.next());
           
            }
         
        bots = new ArrayList();
      
            Iterator<BotPoint2D> bit = currState.bots.iterator();
	
            while(bit.hasNext())
            {
             bots.add(bit.next());
            }
        
                
        //if I can shoot, then aim and shoot
        
        if(shotclock<=0)
        {
            
       // store my location
       x = currState.me.getX();
       y = currState.me.getY();
       
       

       action = 9;
	    storeBots();
	    
            if (action == 9)
            {
                action = rand.nextInt(8);
            }
	   
                      
            shotclock=game.getShotFrequency()+1;
            switch(action)
            {
                case 0:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
                break;
                case 1:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
                break;
                case 2:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
                break;
                case 3:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
                break;
                case 4:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.LEFT);
                break;
                case 5:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                break;
                case 6:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                break;
                default:
                    shotAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                break;
            }
            return shotAction;
        }
        
	else if(currAction==null || rand.nextInt(20)>18)
        {
            double x;
	    double y;
	    x = currState.me.getX();
            y = currState.me.getY();
	    action = 9;
	    
	    storeBullets();
	    
	 if (action==9)
	    {
	    	action = rand.nextInt(8);
	    }
	            
	    
	    switch(action)
            {
                case 0:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                break;
                case 1:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                break;
                case 2:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                break;
                case 3:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                break;
                case 4:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                break;
                case 5:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                break;
                case 6:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                break;
                default:
                    currAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                break;
            }
        }
        return currAction; 
    }
     	


    public String toString()
    {
        return "p9";
    }
}


