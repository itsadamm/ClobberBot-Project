import java.awt.geom.*;
import java.awt.*;
import java.util.*;

public class p6 extends ClobberBot
{

	static ClobberBotAction currAction;
    
    	private int action;
    	private int shotclock,maxid,minid;
    	private boolean DANGER,RBORDER,LBORDER,TBORDER,BBORDER;
    	private boolean[] movesafe = new boolean[9];
	
    	java.util.List bulletID = new ArrayList<Double>();
    	java.util.List bulletX = new ArrayList<Double>();
    	java.util.List bulletY = new ArrayList<Double>();
        
	public p6(Clobber game)
	{
		super(game);
		mycolor=Color.red;
		shotclock = game.getShotFrequency();
    		maxid = 0;
		minid = 0;
		RBORDER = false;
		LBORDER = false;
		TBORDER = false;
		BBORDER = false;
	}
	// 
	// This class is called to allow me to make a move or shot
	// bassed on the current world information.
	// 
	
    public ClobberBotAction takeTurn(WhatIKnow currState)
    {
	currAction = new ClobberBotAction(0,4);
	action = 0;
	DANGER = false;
	
	double Xdiff,Ydiff,Xpos,Ypos,myXpos,myYpos;
	double oldXpos,oldYpos,Xnear,Ynear;
	int tempid,locationindex;
	
	Xnear = 1000;  // Reset the Xnear and Ynear paramaters outside the
	Ynear = 1000;  // screen every turn, in case my target is now gone.
	for (int x=0;x<9;x++){movesafe[x]=true;}
	
	myXpos=currState.me.getX(); // Saves my current X position.
	myYpos=currState.me.getY(); // Saves my current Y position.
	
	// This loop runs through the bullets that currently exist in the
	// the world.  It saves any new bullets origin point in the three array
	// lists. (ID, X and Y).  It also removes any bullets origin info
	// if that bullet is no longer in the world. Only the bullet origin
	// info is saved.  The bullet origin info is only looked at if the bullet
	// comes within a danger zone created around my position.
	
	for (int x=0; x < currState.bullets.size(); x++)
		{

		tempid = ((ImmutablePoint2D)(currState.bullets.get(x))).getID();
		Xpos=currState.bullets.get(x).getX();
		Ypos=currState.bullets.get(x).getY();
		Xdiff = Xpos-myXpos;
		Ydiff = Ypos-myYpos;
		// 
		// this IF is where old bullets are removed from my arraylist
		// 
		if (tempid > minid && minid > 0 && x==0)
			{
			locationindex = bulletID.indexOf(minid);
			if (locationindex != -1)
				{
				bulletID.remove(locationindex);
				bulletX.remove(locationindex);
				bulletY.remove(locationindex);
				}
			x--;
			minid++;
			continue;
			}
		//
		// this IF is where new bullets are added to my array list.
		// 
		if (tempid > maxid)
			{
			bulletID.add(tempid);
			bulletX.add(Xpos);
			bulletY.add(Ypos);
			maxid=tempid;
			if (minid==0) minid=maxid;
			continue;
			}
		//
		// The folowing IF statement is to test if a bullet is within my danger
		// zone.
		//
		if (Math.abs(Xdiff) < 40 && Math.abs(Ydiff) < 40)
			{
			locationindex = bulletID.indexOf(tempid);

			DANGER=true;
			oldXpos = (Double)bulletX.get(locationindex);
			oldYpos = (Double)bulletY.get(locationindex);
			
			// 
			// The following IF statements mark unsafe moves.  These statements
			// are needed in case the bullet is found by the more detailed analysis
			// to be a threat because it has passed my bot.  Without these, the bot
			// will move into bullets that are shooting just passed it.
			//
			if (Xpos <= myXpos && Ypos <= myYpos)  // bullet in upper left corner
				if(Xdiff > -20 && Ydiff > -20)
					movesafe[1]=movesafe[8]=movesafe[7]=false;
			if (Xpos >= myXpos && Ypos <= myYpos)  // bullet in upper right corner
				if(Xdiff < 20 && Ydiff > -20)
					movesafe[1]=movesafe[2]=movesafe[3]=false;
			if (Xpos >= myXpos && Ypos >= myYpos)  // bullet in lower right corner
				if(Xdiff < 20 && Ydiff < 20)
					movesafe[3]=movesafe[4]=movesafe[5]=false;
			if (Xpos <= myXpos && Ypos >= myYpos)  // bullet in lower left corner
				if(Xdiff > -20 && Ydiff < 20)
					movesafe[5]=movesafe[6]=movesafe[7]=false;
			//
			// The following IF statements break down the trajectory to
			// decide if a move is required or not.  They also take away
			// any moves that would be dangerous bassed on the bullets
			// close by.
			// 
			if (Ypos < myYpos && oldYpos < Ypos)  // bullet is above me and going down.
			{
				if (Xpos <= myXpos && oldXpos < Xpos) // bullet comming from upper left
				{	
					if (Ydiff-Xdiff >= -20 && Ydiff-Xdiff <= 0) 
					{
						movesafe[8]=movesafe[1]=movesafe[2]=false;
						movesafe[3]=movesafe[4]=false;
						action=6;
					}
					else if (Ydiff-Xdiff <= 20 && Ydiff-Xdiff > 0)
					{
						movesafe[4]=movesafe[5]=movesafe[6]=false;
						movesafe[7]=movesafe[8]=false;
						action=2;
					}
				}
				else if (Xpos >= myXpos && oldXpos > Xpos) // bullet comming from upper right
				{
					if (Math.abs(Ydiff)-Xdiff <= 20 && Math.abs(Ydiff)-Xdiff >= 0) 
					{
						movesafe[1]=movesafe[2]=movesafe[6]=false;
						movesafe[7]=movesafe[8]=false;
						action=4;
					}
					else if (Math.abs(Ydiff)-Xdiff >= -20 && Math.abs(Ydiff)-Xdiff < 0)
				       	{
						movesafe[2]=movesafe[3]=movesafe[4]=false;
						movesafe[5]=movesafe[6]=false;
						action=8;
					}
				}	
				else if (Xpos == oldXpos) // bullet is comming straight down
				{
					if (Xpos < myXpos && Xdiff > -10) // bullet is on my left comming down
					{
						movesafe[1]=movesafe[5]=movesafe[6]=false;
						movesafe[7]=movesafe[8]=false;
						action=3;
					}
					else if (Xpos > myXpos && Xdiff < 10)  // bullet is on my right comming down
					{
						movesafe[1]=movesafe[2]=movesafe[3]=false;
						movesafe[4]=movesafe[5]=false;
						action=7;
					}
					else if (Xpos == myXpos) // bullet is centered on me comming down
					{	
						movesafe[1]=movesafe[2]=movesafe[8]=false;
						movesafe[4]=movesafe[5]=false;
						action=7;
					}
				}	
			}
			else if (Ypos >= myYpos && oldYpos > Ypos)  // bullet is below and going up.
			{
				if (Xpos <= myXpos && oldXpos < Xpos) // bullet comming from lower left
				{	
					if (Ydiff-Math.abs(Xdiff) <= 20 && Ydiff-Math.abs(Xdiff) >= 0) 
					{
						movesafe[2]=movesafe[3]=movesafe[4]=false;
						movesafe[5]=movesafe[6]=false;
						action=8;
					}
					else if (Ydiff-Math.abs(Xdiff) >= -20 && Ydiff-Math.abs(Xdiff) < 0)
				       	{
						movesafe[6]=movesafe[7]=movesafe[8]=false;
						movesafe[1]=movesafe[2]=false;
						action=4;
					}
				}
				else if (Xpos >= myXpos && oldXpos > Xpos) // bullet comming from lower right
				{
					if (Ydiff-Xdiff <= 20 && Ydiff-Xdiff >= 0) 
					{
						movesafe[4]=movesafe[5]=movesafe[6]=false;
						movesafe[7]=movesafe[8]=false;
						action=2;
					}
					else if (Ydiff-Xdiff >= -20 && Ydiff-Xdiff < 0)
				       	{
						movesafe[8]=movesafe[1]=movesafe[2]=false;
						movesafe[3]=movesafe[4]=false;
						action=6;
					}
				}
				else if (Xpos == oldXpos) // bullet is going straight up
				{
					if (Xpos < myXpos && Xdiff > -10)  // bullet is to my left comming up
					{
						movesafe[5]=movesafe[6]=movesafe[7]=false;
						movesafe[8]=movesafe[1]=false;
						action=3;
					}
					if (Xpos > myXpos && Xdiff < 10)  // bullet is to my right and comming up
					{
						movesafe[1]=movesafe[2]=movesafe[3]=false;
						movesafe[4]=movesafe[5]=false;
						action=7;
					}
					if (Xpos == myXpos)
					{
						movesafe[1]=movesafe[2]=movesafe[8]=false;
						movesafe[5]=false;
						action=3;
					}
				}
			}
			else if (Ypos == oldYpos) // bullet is going right or left
				{
				if (Xpos < myXpos && oldXpos < Xpos) // bullet comming from my left
				{
					if (Ypos  < myYpos && Ydiff > -15)  // bullet is above me going right 
					{	
						movesafe[7]=movesafe[8]=movesafe[1]=false;
						movesafe[2]=movesafe[3]=false;
						action=5;
					}
					if (Ypos  > myYpos && Ydiff < 15) // bullet is below me going right
					{
						movesafe[3]=movesafe[4]=movesafe[5]=false;
						movesafe[6]=movesafe[7]=false;
						action=1;
					}
					if (Ypos  == myYpos) 
					{
						movesafe[7]=movesafe[8]=movesafe[6]=false;
						movesafe[3]=false;
						action=1;
					}
				}
				else if (Xpos > myXpos && oldXpos > Xpos) // bullet comming from my right
				{
					if (Ypos  < myYpos && Ydiff > -15)   // bullet is above me going left
					{
						movesafe[7]=movesafe[8]=movesafe[1]=false;
						movesafe[2]=movesafe[3]=false;
						action=5;
					}
					if (Ypos  > myYpos && Ydiff < 15) // bullet is below me going left
					{
						movesafe[3]=movesafe[4]=movesafe[5]=false;
						movesafe[6]=movesafe[7]=false;
						action=1;
					}
					if (Ypos  == myYpos) 
					{
						movesafe[2]=movesafe[3]=movesafe[4]=false;
						movesafe[7]=false;
						action=5;
					}
				}
			}
			
		}
	}
	//
	// This loop is to look at the enemy bots and see if any are 
	// within the danger zone.  This loop also keeps track of the 
	// closest bot to my position.
	//
	for (int x=0; x < currState.bots.size(); x++)
	{
		Xpos=currState.bots.get(x).getX();
		Ypos=currState.bots.get(x).getY();
		
		Xdiff = Xpos-myXpos;
		Ydiff = Ypos-myYpos;
		//
		// This IF keeps track of the bot closest to me
		//
		if (Math.abs(Xdiff) + Math.abs(Ydiff) < Math.abs(Xnear-myXpos) + Math.abs(Ynear-myYpos))
		{
			Xnear = Xpos;
			Ynear = Ypos;
		}
		//
		// This IF removes any would be dangerous moves from the acceptable
		// move array based on enemy bot locations.  
		//
		if (Math.abs(Xdiff) < 60 && Math.abs(Ydiff) < 60)
		{
			if (Xpos < myXpos && Ypos < myYpos) // bot upper left
			{
				movesafe[8]=false;
				if (Math.abs(Xdiff) <30) movesafe[1]=false;
				if (Math.abs(Ydiff) <30) movesafe[7]=false;
			}
			else if (Xpos < myXpos && Ypos > myYpos)  // bot in lower left area
			{
				movesafe[6]=false;
				if (Math.abs(Xdiff) <30) movesafe[5]=false;
				if (Math.abs(Ydiff) <30) movesafe[7]=false;
			}	
			else if (Xpos > myXpos && Ypos < myYpos)  // bot in upper right area
			{
				movesafe[2]=false;
				if (Math.abs(Xdiff) <30) movesafe[1]=false;
				if (Math.abs(Ydiff) <30) movesafe[3]=false;
			}	
			else if (Xpos > myXpos && Ypos > myYpos)  // bot in lower right area 
			{
				movesafe[4]=false;
				if (Math.abs(Xdiff) <30) movesafe[1]=false;
				if (Math.abs(Ydiff) <30) movesafe[8]=false;
			}	
		}
		//
		// This IF forces me to take a move action if an enemy BOT is too close.
		//
		if (Math.abs(Xdiff) < 25 && Math.abs(Ydiff) < 25)
		{
			if (Xpos < myXpos && Ypos < myYpos) // bot upper left
			{
				action=4;
			}
			else if (Xpos < myXpos && Ypos > myYpos)  // bot in lower left area
			{
				action=2;
			}	
			else if (Xpos > myXpos && Ypos < myYpos)  // bot in upper right area
			{
				action=6;
			}	
			else if (Xpos > myXpos && Ypos > myYpos)  // bot in lower right area 
			{
				action=8;
			}	
			DANGER=true;
		}
	}
	//
	// This IF allows us to shoot if the shotclock says we can. 
	// If we are in danger, we will still shoot at the closest target to us,
	// if the closest target to us is in our cross hairs.
	//
	if (shotclock <= 0)
	{
		Xdiff = Xnear-myXpos;
		Ydiff = Ynear-myYpos;
	
		if (Math.abs(Xdiff) <= 30)
		{
			if (Ydiff < 0) action = 9;  // shoot up
			if (Ydiff > 0) action = 13; // shoot down
		}
		else if (Math.abs(Ydiff) <= 30)
		{
			if (Xdiff < 0) action = 15; // shoot left
			if (Xdiff > 0) action = 11; // shoot right
		}
		else if (Math.abs(Math.abs(Xdiff)-Math.abs(Ydiff)) < 30)
		{
			if (Xdiff < 0 && Ydiff < 0) action = 16; // shoot upper left
			if (Xdiff < 0 && Ydiff > 0) action = 14; // shoot lower left
			if (Xdiff > 0 && Ydiff < 0) action = 10; // shoot upper right	
			if (Xdiff > 0 && Ydiff > 0) action = 12; // shoot lower right
		}
		if (action > 8) shotclock = game.getShotFrequency(); //reset shotclock
	}
	//
	// This IF decides where to move if we can't shoot and we have not selected
	// and action as of yet.  If an action is not selected by this point, then 
	// we must not be in any immediate danger.
	//
	if (action == 0)
	{
		Xdiff = Xnear-myXpos;
		Ydiff = Ynear-myYpos;
		
		if (Ynear < myYpos-8)  // target is above me.
		{
			if (Xnear < myXpos-8) // target is above left
			{	
				if (Ydiff < Xdiff) // target is closer in X
				{	
					if (movesafe[7]) action=7; // move left if left is safe
				}
				else if (Ydiff > Xdiff) // target is closer in Y
				{	
					if (movesafe[1]) action=1; // move up if up is safe
				}
			}
			else if (Xnear > myXpos+8) // target is above right
			{	
				if (Math.abs(Ydiff) > Xdiff) // target is closer in X
				{
					if (movesafe[3]) action=3;  // move right if right is safe
				}
				else if (Math.abs(Ydiff) < Xdiff)  // target is closer in Y
				{
					if (movesafe[1]) action=1;  // move up if up is safe
				}	
			}
		}
		else if (Ynear > myYpos+8)  // target is below me
		{
			if (Xnear < myXpos-8) // target is below left
			{	
				if (Ydiff < Math.abs(Xdiff)) // target is closer in Y
				{
					if (movesafe[5]) action=5; // move down if down is safe
				}
				else if (Ydiff > Math.abs(Xdiff))  // target is closer in X
				{
					if (movesafe[7]) action=7;  // move left if left is safe
				}
			}
			else if (Xnear > myXpos+8) // target is below right
			{	
				if (Ydiff > Xdiff) // target is closer in X
				{
					if (movesafe[3]) action=3;  // move right if right is safe
				}
				else if (Ydiff < Xdiff)  // target is closer in Y
				{
					if (movesafe[5]) action=5;  // move down if down is safe
				}
			}
		}
		
	}
	// 
	// These Ifs set the border boolean variable
	//
	if (game.getMinX()+5 > myXpos) 
	{
		LBORDER=true;
		movesafe[6]=movesafe[7]=movesafe[8]=false;
	}
	if (game.getMaxX()-5 < myXpos) 
	{
		RBORDER=true;
		movesafe[2]=movesafe[3]=movesafe[4]=false;
	}
	if (game.getMinY()+5 > myYpos) 
	{
		TBORDER=true;
		movesafe[8]=movesafe[1]=movesafe[2]=false;
	}
	if (game.getMaxY()-5 < myYpos) 
	{
		BBORDER=true;
		movesafe[6]=movesafe[5]=movesafe[4]=false;
	}
	// 
	// These IF's set reset the border a boolean variable
	//
	if (LBORDER && game.getMinX()+100 < myXpos) LBORDER=false;
	if (RBORDER && game.getMaxX()-100 > myXpos) RBORDER=false;
	if (TBORDER && game.getMinY()+100 < myYpos) TBORDER=false;
	if (BBORDER && game.getMaxY()-100 > myYpos) BBORDER=false;
	// 
	// These IF's try to get my bot away from the edge if there is no 
	// danger and there is no action assigned as of yet.
	//
	if (!DANGER && action < 9)
	{
		if (LBORDER) action=3;
		if (RBORDER) action=7;
		if (TBORDER) action=5;
		if (BBORDER) action=1;
	}
	// 
	// These IF's finalize the action we will take.  They verify that we are 
	// not going to move ourselves into harms way.  If our decesion does move 
	// us into harms way, the list of possible moves will be looked at, and the
	// first one that shows itself to be a safe move will be selected as the move
	// to take.
	// 
	
	if (action<=8)  // this means we are going to move
	{
		if (!movesafe[action]) // this means action will put bot in danger
		{
			for (int x=1; x < 9; x++)
			{
				if (movesafe[x])   // this will select the first safe move available
				{
					action = x;
					break;
				}
				if (x==8)  // this means we have no safe moves to make. 
				{	
					action=0;
					if (RBORDER||LBORDER)  // if at border, run away from bullet.
					{
						if (Ynear>myYpos) action=1;
						else action=5;
					}
					if (TBORDER||BBORDER)  // if at border, run away from bullet.
					{
						if (Xnear>myXpos) action=7;
						else action=3;
					}
				}
			}
		}
	}
	makeDecision(action);
	shotclock--;
	return currAction;	
    }
	
	
	/** Draws my version of clobber bot to the screen.  */
	
	public void drawMe(Graphics page, Point2D me)
	{
		int x,y,line1,line2;
		x=(int)me.getX();
		y=(int)me.getY();
		line1=Clobber.MAX_BOT_GIRTH/2 +1;
		line2=Clobber.MAX_BOT_GIRTH/2 -1;
		page.setColor(Color.white);
		page.drawLine(x-line1,y,x+line1,y);
		page.drawLine(x,y-line1,x,y+line1);
		page.setColor(Color.green);
		page.drawLine(x-line2,y-line2,x+line2,y+line2);
		page.drawLine(x-line2,y+line2,x+line2,y-line2);
	}

	public String toString()
	{
		return "p6";
	}

	public static void makeDecision(int action)
	{
		switch(action)
		{
			case 1:
			currAction = new ClobberBotAction(1,4);
			break;
			case 2:
			currAction = new ClobberBotAction(1,4|32);
			break;
			case 3:
			currAction = new ClobberBotAction(1,32);
			break;
			case 4:
			currAction = new ClobberBotAction(1,8|32);
			break;
			case 5:
			currAction = new ClobberBotAction(1,8);
			break;
			case 6:
			currAction = new ClobberBotAction(1,8|16);
			break;
			case 7:
			currAction = new ClobberBotAction(1,16);
			break;
			case 8:
			currAction = new ClobberBotAction(1,16|4);
			break;
			case 9:
			currAction = new ClobberBotAction(2,4);
			break;
			case 10:
			currAction = new ClobberBotAction(2,4|32);
			break;
			case 11:
			currAction = new ClobberBotAction(2,32);
			break;
			case 12:
			currAction = new ClobberBotAction(2,32|8);
			break;
			case 13:
			currAction = new ClobberBotAction(2,8);
			break;
			case 14:
			currAction = new ClobberBotAction(2,8|16);
			break;
			case 15:
			currAction = new ClobberBotAction(2,16);
			break;
			case 16:
			currAction = new ClobberBotAction(2,16|4);
			break;
			default:
			currAction = new ClobberBotAction(0,4);
		}
	}
}
