import java.awt.geom.*;
import java.awt.*;
import java.util.*;
public class p3 extends ClobberBot
{
	int goDown, goUp, goLeft, goRight, sDown, sUp, sLeft, sRight, counter =  0;
	double myProximity = 24, xCloseness, yCloseness, myBubble = 40, myTarget = 50;
	
	/**
	 * Constructor that sets the game object
	 * 
	 * @param game Current game object
	 */
	public p3(Clobber game)
	{
		super(game);
	}

	/**
	 * Overriden drawMe method.
	 * Draws the clobber bot to the screen.
	 * 
	 * @param page Graphics object from the window
	 * @param myPoint Point2D object representing my location
	 */
	public void drawMe(Graphics page, Point2D myPoint)
	{
		// Draw a white rectangle inside a blue circle on the given point
		int x,y;
        	x=(int)myPoint.getX() - Clobber.MAX_BOT_GIRTH/2 - 1;
        	y=(int)myPoint.getY() - Clobber.MAX_BOT_GIRTH/2 - 1;
		page.setColor(Color.BLUE);
		page.fillOval(x,y,Clobber.MAX_BOT_GIRTH,Clobber.MAX_BOT_GIRTH);
        	page.setColor(Color.WHITE);
        	page.fillRect(x+4,y+4, Clobber.MAX_BOT_GIRTH - 7,Clobber.MAX_BOT_GIRTH - 7);

	}

	/**
	 * Overriden takeTurn method.
	 * Decides the desired action to take.
	 * 
	 * @param reality WhatIKnow object including details about current game status.
	 * @return courseOfAction ClobberBotAction object of what course of action to take.
	 */
	public ClobberBotAction takeTurn(WhatIKnow reality)
	{
		ClobberBotAction courseOfAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
		goDown = 0;
		goUp = 0;
		goLeft = 0;
		goRight = 0;
		sDown = 0;
		sUp = 0;
		sLeft = 0;
		sRight = 0;
		Point2D me = ((Point2D)(reality.me));
		if(reality.bots.size() < 5)
		{
			myProximity = 40;
			myBubble = 1000;
		}
		
		for(int i = 0; i < reality.bullets.size(); i++)
		{
			xCloseness = ((Point2D)reality.bullets.get(i)).getX() - me.getX();
			yCloseness = ((Point2D)reality.bullets.get(i)).getY() - me.getY();
			if(Math.abs(xCloseness) < myProximity && Math.abs(yCloseness) < myProximity)
			{
				if(xCloseness < 0) //bullet is to the left
					goRight++;
				else //bullet is to the right
					goLeft++;
				if(yCloseness < 0) //bullet is above
					goDown++;
				else //bullet is below
					goUp++;
			}
		}
		
		for(int j = 0; j < reality.bots.size(); j++)
		{
			xCloseness = ((Point2D)reality.bots.get(j)).getX() - me.getX();
			yCloseness = ((Point2D)reality.bots.get(j)).getY() - me.getY();
			if(Math.abs(xCloseness) < myBubble && Math.abs(yCloseness) < myBubble)
			{
				if(Math.abs(xCloseness) < myTarget && Math.abs(yCloseness) < myTarget)
				{
					if(xCloseness < 0) //bot is to the left
						sLeft += 2;
					else //bot is to the right
						sRight += 2;
					if(yCloseness < 0) //bot is above
						sUp += 2;
					else //bot is below
						sDown += 2;
				}
				else
				{
					if(xCloseness < 0) //bot is to the left
						sLeft++;
					else //bot is to the right
						sRight++;
					if(yCloseness < 0) //bot is above
						sUp++;
					else //bot is below
						sDown++;
				}
			}
		}

		//decide what to do
		if (goRight > goLeft)
		{
			if(goDown > goUp)
				courseOfAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.DOWN);
			else
				courseOfAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP);
		}
		else if(goRight < goLeft)
		{
			if(goDown > goUp)
				courseOfAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN);
			else
				courseOfAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP);
		}
		else if(sRight > sLeft) //offense
		{
			if(sDown > sUp)
			{
				if(counter < 7)
					courseOfAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT | ClobberBotAction.DOWN);
				else
					courseOfAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.DOWN);
			}
			else
			{
				if(counter < 7)
					courseOfAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT | ClobberBotAction.UP);
				else
					courseOfAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT | ClobberBotAction.UP);
			}
		}
		else if(sRight < sLeft)
		{
			if(sDown > sUp)
			{
				if(counter < 7)
					courseOfAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT | ClobberBotAction.DOWN);
				else
					courseOfAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.DOWN);
			}
			else
			{
				if(counter < 7)
					courseOfAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT | ClobberBotAction.UP);
				else
					courseOfAction = new ClobberBotAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT | ClobberBotAction.UP);
			}
		}
		else
		{
			if(counter < 4)
				courseOfAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
			else if(counter < 6)
				courseOfAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
			else if(counter < 9)
				courseOfAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
			else if(counter < 11)
				courseOfAction = new ClobberBotAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
		}
		
		//maintenance
		if(counter > 10)
			counter = 0;
		else
			counter ++;
		return courseOfAction;
	}

	/**
	 * Overriden toString method.
	 * Returns the name of the class (my login name.)
	 * 
	 * @return String My login name.
	 */
	public String toString()
	{
		return "p3";
	}
}
