
import java.awt.Color;
import java.awt.Graphics;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Vector;

public class p1 extends ClobberBot
{
    ArrayList bullX;
    ArrayList bullY;
    ArrayList botsX;
    ArrayList botsY;
    ClobberBotAction currAction;
    int shotclock;
    
    public p1(Clobber game)
    {
        super(game);
        bullX = new ArrayList();
        bullY = new ArrayList();
        botsX = new ArrayList();
        botsY = new ArrayList();
        shotclock = game.getShotFrequency();
    }

    public ClobberBotAction takeTurn(WhatIKnow whatiknow)
    {
        double myX = whatiknow.me.getX();
        double myY = whatiknow.me.getY();
        shotclock--;
        for(int j = 0; j < bullX.size(); j++)
        {
            bullX.remove(j);
            bullY.remove(j);
        }

        for(int j = 0; j < botsY.size(); j++)
        {
            botsY.remove(j);
            botsX.remove(j);
        }

        for(int i = 0; i < whatiknow.bots.size(); i++)
        {
            botsX.add(Double.valueOf(((Point2D)whatiknow.bots.get(i)).getX()));
            botsY.add(Double.valueOf(((Point2D)whatiknow.bots.get(i)).getY()));
        }

        if(whatiknow.bullets.size() != 0)
        {
            for(int i = 0; i < whatiknow.bullets.size(); i++)
            {
                bullX.add(Double.valueOf(((Point2D)whatiknow.bullets.get(i)).getX()));
                bullY.add(Double.valueOf(((Point2D)whatiknow.bullets.get(i)).getY()));
            }

        }
        if(bulletDanger(myX, myY, bullX, bullY, whatiknow.bullets.size()))
        {
            boolean safeLeft, safeUp, safeRight, safeDown, safeUpLeft, safeUpRight, safeDownLeft, safeDownRight = false;
            safeLeft = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 3);
            safeRight = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 2);
            safeUp = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 1);
            safeDown = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 0);
            safeUpLeft = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 5);
            safeUpRight = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 4);
            safeDownLeft = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 7);
            safeDownRight = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 6);
            
            int closestBullet = getClosestBullet(myX, myY, bullX, bullY, whatiknow.bullets.size());
            switch(closestBullet)
            {
            default:
                break;

            case 1: // Safe down
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                    break;
                }
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                    break;
                }
                if(safeDownRight && !nearBottom(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                    break;
                }
                if(safeDownLeft && !nearLeft(myX, myY) && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                else
                    currAction = createAction(0, ClobberBotAction.UP);
                break;    
             
            case 2: // Safe right
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpLeft && !nearTop(myX, myY) && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpRight && !nearTop(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(safeDownLeft && !nearBottom(myX, myY) && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                    break;
                }
                if(safeDownRight && !nearBottom(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction( ClobberBotAction.SHOOT, ClobberBotAction.UP);
                else
                    currAction = createAction(0,  ClobberBotAction.UP);
                break;    
                
            case 3: // Safe up
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.UP);
                    break;
                }
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.DOWN);
                    break;
                }
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.RIGHT);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.LEFT);
                    break;
                }
                if(safeDownLeft && !nearLeft(myX, myY) && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpRight && !nearTop(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE,  ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                else
                    currAction = createAction(0,  ClobberBotAction.DOWN);
                break;

            case 4: // Safe down
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                    break;
                }
                if(safeUpLeft && !nearTop(myX, myY) && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpRight && !nearTop(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP |ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
                else
                    currAction = createAction(0, ClobberBotAction.DOWN);
                break;

            case 5: // Safe up and right
                if(safeUpRight && !nearTop(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(safeUpLeft && !nearTop(myX, myY) && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                    break;
                }
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                else
                    currAction = createAction(0, ClobberBotAction.UP);
                break;

            case 6: // Safe right
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpLeft && !nearLeft(myX, myY) && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpRight && !nearRight(myX, myY) && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
                else
                    currAction = createAction(0, ClobberBotAction.UP);
                break;

            case 7: // Safe up
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                    break;
                }
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(safeUpRight && !nearRight(myX, myY) && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(safeDownRight && !nearRight(myX, myY) && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                else
                    currAction = createAction(0, ClobberBotAction.DOWN);
                break;
           
            case 8: // Safe up and left
                if(!safeLeft || nearLeft(myX, myY))
                    break;
                if(safeUpLeft && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeDownLeft && !nearLeft(myX, myY) && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                    break;
                }
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
                else
                    currAction = createAction(0, ClobberBotAction.DOWN);
                break;            
            }
            return currAction;
        }
        if(botDanger(myX, myY, botsX, botsY, whatiknow.bots.size()))
        {
            int closestBot = getClosestBot(myX, myY, botsX, botsY, whatiknow.bots.size());
            boolean safeLeft = false;
            boolean safeUp = false;
            boolean safeRight = false;
            boolean safeDown = false;
            boolean safeUpLeft = false;
            boolean safeUpRight = false;
            boolean safeDownLeft = false;
            boolean safeDownRight = false;
            safeLeft = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 3);
            safeRight = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 2);
            safeUp = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 1);
            safeDown = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 0);
            safeUpLeft = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 5);
            safeUpRight = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 4);
            safeDownLeft = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 7);
            safeDownRight = testSafe(myX, myY, botsX, botsY, bullX, bullY, whatiknow.bots.size(), whatiknow.bullets.size(), 6);
            switch(closestBot)
            {
            default:
                break;

            case 1: // Safe down
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                    break;
                }
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                    break;
                }
                if(safeDownRight && !nearBottom(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                    break;
                }
                if(safeDownLeft && !nearLeft(myX, myY) && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                else
                    currAction = createAction(0, ClobberBotAction.UP);
                break;
 
            case 2: // Safe right
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpLeft && !nearTop(myX, myY) && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpRight && !nearTop(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(safeDownLeft && !nearBottom(myX, myY) && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                    break;
                }
                if(safeDownRight && !nearBottom(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
                else
                    currAction = createAction(0, ClobberBotAction.UP);
                break;

            case 3: // Safe up
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                    break;
                }
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                    break;
                }
                if(safeDownLeft && !nearLeft(myX, myY) && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpRight && !nearTop(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                else
                    currAction = createAction(0, ClobberBotAction.DOWN);
                break;

            case 4: // Safe down
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                    break;
                }
                if(safeUpLeft && !nearTop(myX, myY) && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpRight && !nearTop(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
                else
                    currAction = createAction(0, ClobberBotAction.DOWN);
                break;

            case 5: // Safe up and right
                if(safeUpRight && !nearTop(myX, myY) && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(safeUpLeft && !nearTop(myX, myY) && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                    break;
                }
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                else
                    currAction = createAction(0, ClobberBotAction.UP);
                break;
                
            case 6: // Safe right
                if(safeRight && !nearRight(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
                    break;
                }
                if(safeLeft && !nearLeft(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpLeft && !nearLeft(myX, myY) && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUpRight && !nearRight(myX, myY) && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
                else
                    currAction = createAction(0, ClobberBotAction.UP);
                break;
                
            case 7: // Safe up
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                    break;
                }
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(safeUpRight && !nearRight(myX, myY) && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                    break;
                }
                if(safeDownRight && !nearRight(myX, myY) && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                else
                    currAction = createAction(0, ClobberBotAction.DOWN);
                break;                
                
            case 8: // Safe up and left
                if(!safeLeft || nearLeft(myX, myY))
                    break;
                if(safeUpLeft && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
                    break;
                }
                if(safeDownLeft && !nearLeft(myX, myY) && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                    break;
                }
                if(safeUp && !nearTop(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP);
                    break;
                }
                if(safeDown && !nearBottom(myX, myY))
                {
                    currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN);
                    break;
                }
                if(shotclock <= 0)
                    currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
                else
                    currAction = createAction(0, ClobberBotAction.DOWN);
                break;
            
            }
            return currAction;
        }
// -----------------------------------------------------------------------------  
//     Firing control
// -----------------------------------------------------------------------------    
        if(shotclock <= 0 && !nearTop(myX, myY) && !nearBottom(myX, myY) && !nearRight(myX, myY) && !nearLeft(myX, myY))
        {
            shotclock = game.getShotFrequency() + 1;
            int closestBot = getClosestBot(myX, myY, botsX, botsY, whatiknow.bots.size());
            switch(closestBot)
            {

            case 1: // Up and Right
                currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                break;
            case 2: // 'Up
                currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP);
                break;              
            case 3: // Up and Left
                currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.UP | ClobberBotAction.LEFT);
                break;
            case 4: // Left
                currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.LEFT);
                break;
            case 5: // Down and Left
                currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                break;
            case 6: // Safe right
                currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN);
                break;
            case 7: // Down and Right
                currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                break;
            case 8: // Right
                currAction = createAction(ClobberBotAction.SHOOT, ClobberBotAction.RIGHT);
                break;


            }
            return currAction;
        }
        if(nearLeft(myX, myY))
        {
            if(nearTop(myX, myY))
                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
            else
            if(nearBottom(myX, myY))
                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.RIGHT);
            else
                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.RIGHT);
        } else
        if(nearRight(myX, myY))
        {
            if(nearTop(myX, myY))
                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
            else
            if(nearBottom(myX, myY))
                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.UP | ClobberBotAction.LEFT);
            else
                currAction = createAction(ClobberBotAction.MOVE, ClobberBotAction.LEFT);
        } else
        {
            currAction = createAction(0, ClobberBotAction.LEFT);
        }
        return currAction;
    }
// -----------------------------------------------------------------------------  
//     Creates the Action
// -----------------------------------------------------------------------------
    public static ClobberBotAction createAction(int j, int i)
    {
        ClobberBotAction action = new ClobberBotAction((byte)j, i);
        return action;
    }
// -----------------------------------------------------------------------------  
//     Checks for safe areas
// -----------------------------------------------------------------------------
    public boolean testSafe(double myX, double myY, ArrayList botsX, ArrayList botsY, ArrayList bullX, 
            ArrayList bullY, int numBots, int numBullets, int check)
    {
        if(check == 0) // UP
        {
            for(int i = 0; i < numBots; i++)
                if(((Double)botsY.get(i)).doubleValue() < myY && ((Double)botsX.get(i)).doubleValue() < myX + 30 && ((Double)botsX.get(i)).doubleValue() > myX - 30)
                    return false;

            for(int j = 0; j < numBullets; j++)
                if(((Double)bullY.get(j)).doubleValue() < myY && ((Double)bullX.get(j)).doubleValue() < myX + 20 && ((Double)bullX.get(j)).doubleValue() > myX - 20)
                    return false;

            return true;
        }
        if(check == 1)  // UP
        {
            for(int i = 0; i < numBots; i++)
                if(((Double)botsY.get(i)).doubleValue() > myY && ((Double)botsX.get(i)).doubleValue() < myX + 30 && ((Double)botsX.get(i)).doubleValue() > myX - 30)
                    return false;

            for(int j = 0; j < numBullets; j++)
                if(((Double)bullY.get(j)).doubleValue() > myY && ((Double)bullX.get(j)).doubleValue() < myX + 20 && ((Double)bullX.get(j)).doubleValue() > myX - 20)
                    return false;

            return true;
        }
        if(check == 2)  // RIGHT
        {
            for(int i = 0; i < numBots; i++)
                if(((Double)botsX.get(i)).doubleValue() > myX && ((Double)botsY.get(i)).doubleValue() < myY - 30 && ((Double)botsY.get(i)).doubleValue() > myY + 30)
                    return false;

            for(int j = 0; j < numBullets; j++)
                if(((Double)bullX.get(j)).doubleValue() > myX && ((Double)bullY.get(j)).doubleValue() < myY - 20 && ((Double)bullY.get(j)).doubleValue() > myY + 20)
                    return false;

            return true;
        }
        if(check == 3)  // LEFT
        {
            for(int i = 0; i < numBots; i++)
                if(((Double)botsX.get(i)).doubleValue() < myX && ((Double)botsY.get(i)).doubleValue() < myY - 30 && ((Double)botsY.get(i)).doubleValue() > myY + 30)
                    return false;

            for(int j = 0; j < numBullets; j++)
                if(((Double)bullX.get(j)).doubleValue() < myX && ((Double)bullY.get(j)).doubleValue() < myY - 20 && ((Double)bullY.get(j)).doubleValue() > myY + 20)
                    return false;

            return true;
        }
        if(check == 4)  // Up Right
        {
            for(int i = 0; i < numBots; i++)
                if(((Double)botsX.get(i)).doubleValue() > myX && ((Double)botsY.get(i)).doubleValue() < myY && Math.sqrt(Math.pow(((Double)botsX.get(i)).doubleValue() - myX, 2) + Math.pow(((Double)botsY.get(i)).doubleValue() - myY, 2)) < 30)
                    return false;

            for(int j = 0; j < numBullets; j++)
                if(((Double)bullX.get(j)).doubleValue() > myX && ((Double)bullY.get(j)).doubleValue() < myY && Math.sqrt(Math.pow(((Double)bullX.get(j)).doubleValue() - myX, 2) + Math.pow(((Double)bullY.get(j)).doubleValue() - myY, 2)) < 20)
                    return false;

            return true;
        }
        if(check == 5)  // Up Left
        {
            for(int i = 0; i < numBots; i++)
                if(((Double)botsX.get(i)).doubleValue() < myX && ((Double)botsY.get(i)).doubleValue() < myY && Math.sqrt(Math.pow(((Double)botsX.get(i)).doubleValue() - myX, 2) + Math.pow(((Double)botsY.get(i)).doubleValue() - myY, 2)) < 30)
                    return false;

            for(int j = 0; j < numBullets; j++)
                if(((Double)bullX.get(j)).doubleValue() < myX && ((Double)bullY.get(j)).doubleValue() < myY && Math.sqrt(Math.pow(((Double)bullX.get(j)).doubleValue() - myX, 2) + Math.pow(((Double)bullY.get(j)).doubleValue() - myY, 2)) < 20)
                    return false;

            return true;
        }
        if(check == 6)  //Down Right
        {
            for(int i = 0; i < numBots; i++)
                if(((Double)botsX.get(i)).doubleValue() > myX && ((Double)botsY.get(i)).doubleValue() > myY && Math.sqrt(Math.pow(((Double)botsX.get(i)).doubleValue() - myX, 2) + Math.pow(((Double)botsY.get(i)).doubleValue() - myY, 2)) < 30)
                    return false;

            for(int j = 0; j < numBullets; j++)
                if(((Double)bullX.get(j)).doubleValue() > myX && ((Double)bullY.get(j)).doubleValue() > myY && Math.sqrt(Math.pow(((Double)bullX.get(j)).doubleValue() - myX, 2) + Math.pow(((Double)bullY.get(j)).doubleValue() - myY, 2)) < 20)
                    return false;

            return true;
        }
        if(check == 7)  //Down Left
        {
            for(int i = 0; i < numBots; i++)
                if(((Double)botsX.get(i)).doubleValue() < myX && ((Double)botsY.get(i)).doubleValue() > myY && Math.sqrt(Math.pow(((Double)botsX.get(i)).doubleValue() - myX, 2) + Math.pow(((Double)botsY.get(i)).doubleValue() - myY, 2)) < 30)
                    return false;

            for(int j = 0; j < numBullets; j++)
                if(((Double)bullX.get(j)).doubleValue() < myX && ((Double)bullY.get(j)).doubleValue() > myY && Math.sqrt(Math.pow(((Double)bullX.get(j)).doubleValue() - myX, 2) + Math.pow(((Double)bullY.get(j)).doubleValue() - myY, 2)) < 20)
                    return false;

            return true;
        } else
        {
            return false;
        }
    }
// -----------------------------------------------------------------------------  
//     Checks for danger
// -----------------------------------------------------------------------------
    public boolean botDanger(double myX, double myY, ArrayList botsX, ArrayList botsY, int numBots)
    {
        double distance = 1000;
        for(int i = 0; i < numBots; i++)
            if(Math.sqrt(Math.pow(myX - ((Double)botsX.get(i)).doubleValue(), 2) + Math.pow(myY - ((Double)botsY.get(i)).doubleValue(), 2)) < distance)
                distance = Math.sqrt(Math.pow(((Double)botsX.get(i)).doubleValue() - myX, 2) + Math.pow(((Double)botsY.get(i)).doubleValue() - myY, 2));

        return distance <= 35;
    }
// -----------------------------------------------------------------------------  
//     Figures bottom
// -----------------------------------------------------------------------------
    public boolean nearBottom(double myX, double myY)
    {
        return (double)(game.getMaxY() - 20) < myY;
    }
// -----------------------------------------------------------------------------  
//     Figures top
// -----------------------------------------------------------------------------
    public boolean nearTop(double myX, double myY)
    {
        return (double)(game.getMinY() + 20) > myY;
    }
// -----------------------------------------------------------------------------  
//     Figures Right side
// -----------------------------------------------------------------------------
    public boolean nearRight(double myX, double myY)
    {
        return (double)(game.getMaxX() - 20) < myX;
    }
// -----------------------------------------------------------------------------  
//     Figures Left side
// -----------------------------------------------------------------------------
    public boolean nearLeft(double myX, double myY)
    {
        return (double)(game.getMinX() + 20) > myX;
    }

// -----------------------------------------------------------------------------  
//     Figures range
// -----------------------------------------------------------------------------
    public boolean bulletDanger(double myX, double myY, ArrayList bullX, ArrayList bullY, int numBullets)
    {
        double distance = 1000;
        for(int i = 0; i < numBullets; i++)
            if(Math.sqrt(Math.pow(myX - ((Double)bullX.get(i)).doubleValue(), 2) + Math.pow(myY - ((Double)bullY.get(i)).doubleValue(), 2)) < distance)
                distance = Math.sqrt(Math.pow(((Double)bullX.get(i)).doubleValue() - myX, 2) + Math.pow(((Double)bullY.get(i)).doubleValue() - myY, 2));

        return distance <= 70;
    }
// -----------------------------------------------------------------------------  
//     Finds closest bot
// -----------------------------------------------------------------------------
    public int getClosestBot(double myX, double myY, ArrayList botsX, ArrayList botsY, int numBots)
    {
        double closestX = ((Double)botsX.get(0)).doubleValue();
        double closestY = ((Double)botsY.get(0)).doubleValue();
        double distance = 1000;
        for(int i = 0; i < numBots; i++)
            if(Math.sqrt(Math.pow(((Double)botsX.get(i)).doubleValue() - myX, 2) + Math.pow(((Double)botsY.get(i)).doubleValue() - myY, 2)) < distance)
            {
                distance = Math.sqrt(Math.pow(((Double)botsX.get(i)).doubleValue() - myX, 2D) + Math.pow(((Double)botsY.get(i)).doubleValue() - myY, 2D));
                closestX = ((Double)botsX.get(i)).doubleValue();
                closestY = ((Double)botsY.get(i)).doubleValue();
            }

        double angle = Math.toDegrees(Math.atan((myY - closestY) / (myX - closestX)));
        if(angle <= -30 && angle > -50)
            return 1;
        if(angle <= -50 && angle > -120)
            return 2;
        if(angle <= -120 && angle > -150)
            return 3;
        if(angle >= 150 && angle <= 180 || angle <= -150 && angle >= -180)
            return 4;
        if(angle >= 120 && angle < 150)
            return 5;
        if(angle >= 50 && angle < 120)
            return 6;
        return angle < 30 || angle >= 50 ? 8 : 7;
    }
// -----------------------------------------------------------------------------  
//     Finds the closest bullet
// -----------------------------------------------------------------------------
    public int getClosestBullet(double myX, double myY, ArrayList bullX, ArrayList bullY, int numBullets)
    {
        double closestX = ((Double)botsX.get(0)).doubleValue();
        double closestY = ((Double)botsY.get(0)).doubleValue();
        double distance = 1000;
        for(int i = 0; i < numBullets; i++)
            if(Math.sqrt(Math.pow(((Double)bullX.get(i)).doubleValue() - myX, 2) + Math.pow(((Double)bullY.get(i)).doubleValue() - myY, 2)) < distance)
            {
                distance = Math.sqrt(Math.pow(((Double)bullX.get(i)).doubleValue() - myX, 2) + Math.pow(((Double)bullY.get(i)).doubleValue() - myY, 2));
                closestX = ((Double)bullX.get(i)).doubleValue();
                closestY = ((Double)bullY.get(i)).doubleValue();
            }

        double angle = Math.toDegrees(Math.atan((myY - closestY) / (myX - closestX)));
        if(angle <= -30 && angle > -50)
            return 1;
        if(angle <= -50 && angle > -120)
            return 2;
        if(angle <= -120 && angle > -150)
            return 3;
        if(angle >= 150 && angle <= 180 || angle <= -150 && angle >= -180)
            return 4;
        if(angle >= 120 && angle < 150)
            return 5;
        if(angle >= 50 && angle < 120)
            return 6;
        return angle < 30 || angle >= 50 ? 8 : 7;
    }
// -----------------------------------------------------------------------------  
//     Draws bot
// -----------------------------------------------------------------------------
       public void drawMe(Graphics g, Point2D point2d)
    {
        Color color = Color.gray;
        if(shotclock <= 20 && shotclock >= 18)
            color = Color.white;
        int x,y;
        x=(int)point2d.getX() - Clobber.MAX_BOT_GIRTH/2 -1;
        y=(int)point2d.getY() - Clobber.MAX_BOT_GIRTH/2 -1;
        g.setColor(color);
        g.fillOval(x,y, 5,5);
        g.fillOval(x-5,y, 5,5);
        g.fillOval(x,y-5, 5,5);
        g.fillOval(x+5,y, 5,5);
        g.fillOval(x,y+5, 5,5);
    }
// -----------------------------------------------------------------------------  
//     Text display output
// -----------------------------------------------------------------------------
    public String toString()
    {
        return "p1";
    }
}
