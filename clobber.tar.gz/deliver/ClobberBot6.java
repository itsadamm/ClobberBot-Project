import java.awt.geom.*;
import java.awt.*;
import java.util.*;
public class ClobberBot6 extends ClobberBot
{
    private static final int BULLET_RANGE = 40;    //40!!!
    private static final int BOT_RANGE = 40;    
    private static final int BOT_WINDOW = 80; 
    
    private boolean tooClose; 
    private int movement;
    private int shotclock;
    private String action; 
    private ClobberBotAction currAction;
    private ImmutablePoint2D[] previousBullets;

    /**
    * Constructor
    * @param game the Clobber object in which the game is played
    */
    public ClobberBot6(Clobber game)
    {
        super(game);
        previousBullets = new ImmutablePoint2D[0];
        action = "nothing";
        movement = 0;
        tooClose = false;
        shotclock = 0;
    }

    /**
     * Determines the best course of action to destroy all other bots while staying alive.
     * @return ClobberBotAction The decided upon action
     * @param currState The current world state
     */
    public ClobberBotAction takeTurn(WhatIKnow currState)
    {
        shotclock--;
        double closestBullet = 5000;
        double closestBot = 5000;
        int closestBulletIndex = 0;
        int closestBotIndex = 0;

        for(int x = 0; x<currState.bullets.size(); x++)//Find closest Bullet
        {
            double bulletDist = currState.me.distance((ImmutablePoint2D)currState.bullets.get(x));
            if(bulletDist < closestBullet) { closestBullet = bulletDist; closestBulletIndex = x;}
        }

        for(int x=0; x<currState.bots.size();x++) //Find closest Bot
        {
            double botDist = currState.me.distance((ImmutablePoint2D)currState.bots.get(x));
            if(botDist < closestBot) {closestBot = botDist; closestBotIndex = x;}
        }
        
        if(shotclock<=0)//If able to shoot, shoot at closest Bot
        {
            action = "shoot";
            shotAction(currState, closestBotIndex);
        }
        else //unable to shoot
        {
            action = "move";

            if(closestBullet > BULLET_RANGE)//not in danger
            {
                moveAction(currState, closestBotIndex, closestBot);
            }
            else    //closest bullet is within BULLET_RANGE 
            {
                dodgeAction(currState, closestBulletIndex, closestBotIndex, closestBot);
            }
        }
        previousBullets = new ImmutablePoint2D[currState.bullets.size()];
        currState.bullets.copyInto(previousBullets);

        currAction = createAction(action, movement);

        return currAction;
    }
    private void dodgeAction(WhatIKnow worldState, int bulletIndex, int botIndex, double botProximity)
    {
        WhatIKnow currState = worldState;
        int closestBulletIndex = bulletIndex;
        int closestBotIndex = botIndex;
        double closestBot = botProximity;
        
        double bulletX = ((ImmutablePoint2D)currState.bullets.get(closestBulletIndex)).getX();
        double bulletY = ((ImmutablePoint2D)currState.bullets.get(closestBulletIndex)).getY();

        double meX =  ((ImmutablePoint2D)currState.me).getX();
        double meY =  ((ImmutablePoint2D)currState.me).getY();

        int bulletCurrentID = ((ImmutablePoint2D)currState.bullets.get(closestBulletIndex)).getID();
        int bulletPreviousIndex = -1;

        for(int p = 0; p < previousBullets.length; p++)
        {
            if(bulletCurrentID == previousBullets[p].getID())
            {
                bulletPreviousIndex = p;
                break;
            }
        }

        if(bulletPreviousIndex >= 0) //record exists of the bullet
        {
            action = "move";

            double previousBulletX = previousBullets[bulletPreviousIndex].getX();
            double previousBulletY = previousBullets[bulletPreviousIndex].getY();

            //can use currState.me.distance() for current and previous bullet b/c bullets move faster than bots
            double currentDist = currState.me.distance((ImmutablePoint2D)currState.bullets.get(closestBulletIndex));
            double previousDist = currState.me.distance((ImmutablePoint2D)previousBullets[bulletPreviousIndex]);

            if(currentDist >= previousDist) //bullet is moving away
            {
                moveAction(worldState, closestBotIndex, closestBot);
            }
                    
            else //bullet is moving towards
            {
                int dangerZone = Clobber.MAX_BOT_GIRTH/2 + Clobber.BULLET_GIRTH/2;
                        
                if(bulletX == previousBulletX) //bullet is moving vertically
                {
                    if(bulletX <= meX)movement = 0;
                    else movement = 4;
                    if(Math.abs(meX - bulletX) > dangerZone) action = "nothing";
                }
                else if(bulletY == previousBulletY)//bullet is moving horizontally
                {
                    if(bulletY <= meY) movement = 6;
                    else movement = 2;
                    if(Math.abs(meY - bulletY) > dangerZone) action = "nothing";
                }
                else //bullet is moving diagonally
                {
                    double m = ((bulletY - previousBulletY))/(double)(bulletX - previousBulletX);
                    double intercept = m*meY-bulletY*m+bulletX;
                    int diagDangerZone = (int)((Math.pow((2*Math.pow(dangerZone,2)),0.5))+2); 

                    if(m == -1)
                    {
                        if (intercept <= meX + diagDangerZone && intercept >= meX - diagDangerZone)
                        {
                            if(intercept >= meX) movement = 3;
                            else movement = 7;
                        }
                        else action = "nothing";
                    }
                    else
                    {
                        if (intercept <= meX+diagDangerZone && intercept >= meX-diagDangerZone)
                        {
                            if(intercept >= meX) movement = 5;
                            else movement = 1;
                        }
                        else action = "nothing";
                    }
                }
            }
        }
        else //no record exists - use closestBotIndex to project bullet trajectory
        {
            action = "move";

            double previousBulletX = ((ImmutablePoint2D)currState.bots.get(closestBotIndex)).getX();
            double previousBulletY = ((ImmutablePoint2D)currState.bots.get(closestBotIndex)).getY();

            //can use currState.me.distance() for current and previous bullet b/c bullets move faster than bots
            double bulletDist  = currState.me.distance((ImmutablePoint2D)currState.bullets.get(closestBulletIndex));
            double botDist = currState.me.distance((ImmutablePoint2D)currState.bots.get(closestBotIndex));

            if(bulletDist >= botDist) //bullet is moving away
            {
                moveAction(worldState, closestBotIndex, closestBot);
            }
                    
            else //bullet is moving towards
            {
                int dangerZone = Clobber.MAX_BOT_GIRTH/2 + Clobber.BULLET_GIRTH/2;
                        
                if(bulletX == previousBulletX) //bullet is moving vertically
                {
                    if(bulletX <= meX)movement = 0;
                    else movement = 4;
                    if(Math.abs(meX - bulletX) > dangerZone) action = "nothing";
                }
                else if(bulletY == previousBulletY)//bullet is moving horizontally
                {
                    if(bulletY <= meY) movement = 6;
                    else movement = 2;
                    if(Math.abs(meY - bulletY) > dangerZone) action = "nothing";
                }
                else //bullet is moving diagonally
                {
                    double m = ((bulletY - previousBulletY))/(double)(bulletX - previousBulletX);
                    double intercept = m*meY-bulletY*m+bulletX;
                    int diagDangerZone = (int)((Math.pow((2*Math.pow(dangerZone,2)),0.5))+2); 

                    if(m == -1)
                    {
                        if (intercept <= meX + diagDangerZone && intercept >= meX - diagDangerZone)
                        {
                            if(intercept >= meX) movement = 3;
                            else movement = 7;
                        }
                        else action = "nothing";
                    }
                    else
                    {
                        if (intercept <= meX+diagDangerZone && intercept >= meX-diagDangerZone)
                        {
                            if(intercept >= meX) movement = 5;
                            else movement = 1;
                        }
                        else action = "nothing";
                    }
                }
            }
        }
    }
    private void moveAction(WhatIKnow worldState,int botIndex, double botProximity)
    {
        WhatIKnow currState = worldState;
        int closestBotIndex = botIndex;
        double closestBot = botProximity;

        double botX = ((ImmutablePoint2D)currState.bots.get(closestBotIndex)).getX();
        double botY = ((ImmutablePoint2D)currState.bots.get(closestBotIndex)).getY();
        double meX =  ((ImmutablePoint2D)currState.me).getX();
        double meY =  ((ImmutablePoint2D)currState.me).getY();
        double theta = Math.toDegrees(Math.atan((botY-meY) / (botX-meX)));
        boolean isAbove = false;

        if(((ImmutablePoint2D)currState.bots.get(closestBotIndex)).getY() <= currState.me.getY())isAbove = true;
        if(closestBot > BOT_RANGE + BOT_WINDOW)tooClose = false;

        if(!tooClose && closestBot > BOT_RANGE) //Move to get a bead on closest bot
        {
            if(isAbove)
            {    
                if(botX >= meX)
                {
                    if(theta >= -27 && theta <= 0) movement = 2;
                    if(theta >= -44 && theta < -27) movement = 7;
                    if(theta == -45) movement = 1;
                    if(theta >= -63&& theta < -46) movement = 3;
                    if(theta >= -90 && theta < -63) movement = 0;
                }
                else
                {
                    if(theta <= 27 && theta >= 0) movement = 2;
                    if(theta <= 44 && theta > 27) movement = 5;
                    if(theta == 45) movement = 3;
                    if(theta <= 63 && theta > 46) movement = 1;
                    if(theta <= 90 && theta > 63) movement = 4;
                }
            }
            else
            {
                if(botX >= meX)
                {
                    if(theta <= 27 && theta >= 0) movement = 6;
                    if(theta <= 44 && theta > 27) movement = 1;
                    if(theta == 45) movement = 7;
                    if(theta <= 63 && theta > 46) movement = 5;
                    if(theta <= 90 && theta > 63) movement = 0;
                }
                else
                {
                    if(theta >= -27 && theta <= 0) movement = 6;
                    if(theta >= -44 && theta < -27) movement = 3;
                    if(theta == 45) movement = 5;
                    if(theta >= -63 && theta < -46) movement = 7;
                    if(theta >= -90 && theta < -63) movement = 4;
                }
            }
        }
        else //Move away from closest bot 
        {
            tooClose = true;
            if(isAbove)
            {    
                if(botX >= meX)
                {
                    if(theta >= -20 && theta <= 0) movement = 4;
                    if(theta >= -70 && theta < -20) movement = 5;
                    if(theta >= -90 && theta < -70) movement = 6;
                }
                else
                {
                    if(theta <= 20 && theta >= 0) movement = 0;
                    if(theta <= 70 && theta > 20) movement = 7;
                    if(theta <= 90 && theta > 70) movement = 6;
                }
            }
            else
            {    
                if(botX >= meX)
                {
                    if(theta >= -20 && theta <= 0) movement = 0;
                    if(theta >= -70 && theta < -20) movement = 1;
                    if(theta >= -90 && theta < -70) movement = 2;
                }
                else
                {
                    if(theta <= 20 && theta >= 0) movement = 4;
                    if(theta <= 70 && theta > 20) movement = 3;
                    if(theta <= 90 && theta > 70) movement = 2;
                }
            }
        }
    }
    private void shotAction(WhatIKnow worldState, int botIndex)
    {
        WhatIKnow currState = worldState;
        int closestBotIndex = botIndex;

        shotclock=game.getShotFrequency()+1;        
            
        double botX = ((ImmutablePoint2D)currState.bots.get(closestBotIndex)).getX();
        double botY = ((ImmutablePoint2D)currState.bots.get(closestBotIndex)).getY();
        double meX =  ((ImmutablePoint2D)currState.me).getX();
        double meY =  ((ImmutablePoint2D)currState.me).getY();
        double theta = Math.toDegrees(Math.atan((botY-meY) / (botX-meX))); //degrees to closest bot relative to meX
        boolean isAbove = false;

        if(((ImmutablePoint2D)currState.bots.get(closestBotIndex)).getY() <= currState.me.getY())isAbove = true;

        if(isAbove)
        {    
            if(botX >= meX)
            {
                if(theta >= -10 && theta <= 0) movement = 0;
                if(theta >= -35 && theta < -10) movement = rand.nextInt(2);
                if(theta >= -55 && theta < -35) movement = 1;
                if(theta >= -80 && theta < -55) movement = rand.nextInt(2)+1;
                if(theta >= -90 && theta < -80) movement = 2;
            }
            else
            {
                if(theta <= 10 && theta >= 0) movement = 4;
                if(theta <= 35 && theta > 10) movement = rand.nextInt(2)+3;
                if(theta <= 55 && theta > 35) movement = 3;
                if(theta <= 80 && theta > 55) movement = rand.nextInt(2)+2;
                if(theta <= 90 && theta > 80) movement = 2;
            }
        }
        else
        {
            if(botX >= meX)
            {
                if(theta <= 10 && theta >= 0) movement = 0;
                if(theta <= 35 && theta > 10) {int temp = rand.nextInt(2);if(temp==0)movement=0;else movement=7;}
                if(theta <= 55 && theta > 35) movement = 7;
                if(theta <= 80 && theta > 55) movement = rand.nextInt(2)+6;
                if(theta <= 90 && theta > 80) movement = 6;
            }
            else
            {
                if(theta >= -10 && theta <= 0) movement = 4;
                if(theta >= -35 && theta < -10) movement = rand.nextInt(2)+4;
                if(theta >= -55 && theta < -35) movement = 5;
                if(theta >= -80 && theta < -55) movement = rand.nextInt(2)+5;
                if(theta >= -90 && theta < -80) movement = 6;
            }
        }
    }

    private ClobberBotAction createAction(String $action, int $movement)
    {
        int x=0;
        ClobberBotAction temp;
        if($action.equals("nothing"))x=0; 
        if($action.equals("move")) x=1;
        if($action.equals("shoot")) x=2;

        switch($movement)
        {
            case 0:
                temp = new ClobberBotAction(x, ClobberBotAction.RIGHT);
                break;
            case 1:
                temp = new ClobberBotAction(x, ClobberBotAction.UP | ClobberBotAction.RIGHT);
                break;
            case 2:
                temp = new ClobberBotAction(x, ClobberBotAction.UP);
                break;
            case 3:
                temp = new ClobberBotAction(x, ClobberBotAction.UP | ClobberBotAction.LEFT);
                break;
            case 4:
                temp = new ClobberBotAction(x, ClobberBotAction.LEFT);
                break;
            case 5:
                temp = new ClobberBotAction(x, ClobberBotAction.DOWN | ClobberBotAction.LEFT);
                break;
            case 6:
                temp =  new ClobberBotAction(x, ClobberBotAction.DOWN);
                break;
            default:
                temp = new ClobberBotAction(x, ClobberBotAction.DOWN | ClobberBotAction.RIGHT);
                break;
        }
        return temp;
    }

    /** 
    * Draws the Death Star. 
    * The Death Star summons the power of the dark side every time it fires a bullet, resulting in a flash of red.
    * @param page the Graphics on which to be drawn
    * @param me the center point around which the immage will be drawn
    */
    public void drawMe(Graphics page, Point2D me)
    {
        Color myColor = Color.gray;
        if(shotclock <= 19 && shotclock >= 17) myColor = Color.red;

        int x,y;
        x=(int)me.getX() - Clobber.MAX_BOT_GIRTH/2 -1;
        y=(int)me.getY() - Clobber.MAX_BOT_GIRTH/2 -1;
        page.setColor(Color.lightGray);
        page.fillOval(x,y, Clobber.MAX_BOT_GIRTH,Clobber.MAX_BOT_GIRTH);

        int c,d;
        c=(int)me.getX() - Clobber.MAX_BOT_GIRTH/2 ;
        d=(int)me.getY() - Clobber.MAX_BOT_GIRTH/2 ;
        page.setColor(myColor);
        page.fillOval(c,d, Clobber.MAX_BOT_GIRTH,Clobber.MAX_BOT_GIRTH);

        int a,b;
        a=(int)me.getX() - Clobber.MAX_BOT_GIRTH/2 +1;
        b=(int)me.getY() - Clobber.MAX_BOT_GIRTH/2 +1;
        page.setColor(Color.darkGray);
        page.fillOval(a,b, Clobber.MAX_BOT_GIRTH/2,Clobber.MAX_BOT_GIRTH/2);

        int g,h;
        g=(int)me.getX() - Clobber.MAX_BOT_GIRTH/2 +1;
        h=(int)me.getY() - Clobber.MAX_BOT_GIRTH/2 +1;
        page.setColor(Color.black);
        page.drawArc(g,h, Clobber.MAX_BOT_GIRTH/2,Clobber.MAX_BOT_GIRTH/2,90,90);

        int e,f;
        e=(int)me.getX() - Clobber.MAX_BOT_GIRTH/2 -1;
        f=(int)me.getY() - Clobber.MAX_BOT_GIRTH/6 -1;
        page.setColor(Color.black);
        page.drawArc(e,f, Clobber.MAX_BOT_GIRTH-1,Clobber.MAX_BOT_GIRTH/3,180,180);
    }

    /**
     * Prints out vital info to the screen: Bot Name: Death Star and author name: Ethan Atlakson
     */
    public String toString()
    {
        return "ClobberBot6";
    }
}


